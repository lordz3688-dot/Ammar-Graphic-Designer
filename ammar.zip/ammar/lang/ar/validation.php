<?php

return [
    'required' => 'حقل :attribute مطلوب.',
    'image' => 'يجب أن يكون الحقل :attribute صورة.',
    'max' => [
        'numeric' => 'يجب أن لا يتجاوز الحقل :attribute :max.',
        'file' => 'يجب أن لا يتجاوز حجم الملف :attribute :max كيلوبايت.',
        'string' => 'يجب أن لا يتجاوز الحقل :attribute :max حرفاً.',
    ],
    'attributes' => [
        'title' => 'العنوان',
        'description' => 'الوصف',
        'category' => 'التصنيف',
        'images' => 'الصور',
        'images.*' => 'الصورة المرفوعة',
        'cover_index' => 'صورة الغلاف',
    ],
];
