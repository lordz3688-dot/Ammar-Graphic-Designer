<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    public const HOME = '/';

    public function boot(): void
    {
        $this->ensureSettingsTable();

        $this->routes(function () {
            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });
    }

    private function ensureSettingsTable(): void
    {
        try {
            if (!\Illuminate\Support\Facades\Schema::hasTable('settings')) {
                \Illuminate\Support\Facades\Schema::create('settings', function ($table) {
                    $table->string('key')->primary();
                    $table->text('value')->nullable();
                });
            }

            $defaults = [
                'hero_title' => 'أحوّل الأفكار إلى تجارب بصرية واضحة ومؤثرة.',
                'hero_eyebrow' => 'مصمم جرافيك',
                'hero_description' => 'أصمم هويات بصرية، مواد تسويقية، ومنشورات رقمية تجمع بين الجمال والهدف العملي. أتعامل مع كل مشروع كرسالة تحتاج إلى شكل ذكي وصوت بصري مميز.',
                'experience_years' => '4+',
                'adobe_tools' => '3',
                'accent_text' => '100%',
                'my_photo' => 'photo/myphoto.png',
                'about_bio' => 'مرحباً، أنا مصمم جرافيك شغوف، أمتلك خبرة تمتد لأربع سنوات في تحويل الأفكار والرؤى إلى واقع بصري ملموس. على مدار مسيرتي المهنية، ركزت على تقديم تصاميم تجمع بين الجمالية البصرية والوظيفة العملية التي تخدم أهداف العمل.',
                'about_summary' => 'أؤمن أن التصميم ليس مجرد ألوان وأشكال، بل هو لغة لحل المشكلات وإيصال الرسائل. يسعدني دائماً التعاون مع شركاء نجاح جدد لترك بصمة بصرية مميزة.',
                'whatsapp_url' => 'https://wa.me/967770561991',
                'behance_url' => 'https://www.behance.net/ammarsalim4',
                'twitter_url' => 'https://x.com/LordZer53859986',
                'experiences_json' => json_encode([
                    ['title' => 'خبرة تصميم تمتد لأربع سنوات', 'desc' => 'تحويل الأفكار والرؤى إلى حلول بصرية قابلة للاستخدام في التسويق، الهوية، المحتوى الرقمي، والمطبوعات.'],
                    ['title' => 'منهجية عمل احترافية', 'desc' => 'فهم الهدف أولاً، بناء اتجاه بصري واضح، ثم تنفيذ تصميم متوازن يخدم الرسالة ويعزز حضور العلامة.']
                ], JSON_UNESCAPED_UNICODE),
                'tools_json' => json_encode([
                    ['name' => 'Adobe Photoshop', 'desc' => 'لدمج الصور، التعديل المتقدم، وخلق المؤثرات البصرية الساحرة.', 'icon' => 'fa-solid fa-layer-group'],
                    ['name' => 'Adobe Illustrator', 'desc' => 'لبناء الهويات البصرية، الشعارات، والرسومات المتجهية بدقة متناهية.', 'icon' => 'fa-solid fa-vector-square'],
                    ['name' => 'Adobe InDesign', 'desc' => 'لتنسيق المطبوعات، الكتب الرقمية، والمجلات بهندسة بصرية مريحة للقارئ.', 'icon' => 'fa-solid fa-book']
                ], JSON_UNESCAPED_UNICODE)
            ];

            foreach ($defaults as $key => $val) {
                if (!\Illuminate\Support\Facades\DB::table('settings')->where('key', $key)->exists()) {
                    \Illuminate\Support\Facades\DB::table('settings')->insert([
                        'key' => $key,
                        'value' => $val
                    ]);
                }
            }
        } catch (\Exception $e) {
            // Log or ignore if db is not ready yet during command line boots
        }
    }
}
