<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Offer;
use App\Models\Project;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class PortfolioController extends Controller
{
    protected $settings;

    public function __construct()
    {
        try {
            $this->settings = \Illuminate\Support\Facades\DB::table('settings')->pluck('value', 'key')->all();
            $this->settings['experiences'] = json_decode($this->settings['experiences_json'] ?? '[]', true);
            $this->settings['tools'] = json_decode($this->settings['tools_json'] ?? '[]', true);
            view()->share('settings', $this->settings);
        } catch (\Exception $e) {
            // Ignore if DB not ready
        }
    }

    public function home()
    {
        return view('home', [
            'offers' => Offer::query()->get(),
            'comments' => Comment::query()
                ->where('status', 'approved')
                ->latest('created_at')
                ->limit(6)
                ->get(),
        ]);
    }

    public function works()
    {
        $this->ensureProjectCommentsColumn();

        $projects = Project::query()
            ->with('images')
            ->latest('created_at')
            ->get()
            ->groupBy('category');

        return view('works', compact('projects'));
    }

    public function work(Project $project)
    {
        $this->ensureProjectCommentsColumn();

        $project->load(['images', 'comments' => function ($query) {
            $query->where('status', 'approved')->latest('created_at');
        }]);

        return view('work-show', compact('project'));
    }

    public function storeComment(Request $request, Project $project)
    {
        $this->ensureProjectCommentsColumn();

        $data = $request->validate([
            'user_name' => ['required', 'string', 'max:120'],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'comment' => ['required', 'string', 'max:1200'],
        ]);

        $project->comments()->create([
            'user_name' => $data['user_name'],
            'rating' => $data['rating'],
            'comment' => $data['comment'],
            'status' => 'pending',
            'created_at' => now(),
        ]);

        return redirect()
            ->route('works.show', $project)
            ->with('message', 'تم إضافة تعليقك وتقييمك بنجاح، وسوف يظهر بالموقع فور اعتماده من الإدارة.');
    }

    public function resume()
    {
        return view('resume');
    }

    public function contact()
    {
        return view('contact');
    }

    private function ensureProjectCommentsColumn(): void
    {
        if (! Schema::hasColumn('comments', 'project_id')) {
            Schema::table('comments', function ($table) {
                $table->integer('project_id')->nullable()->index();
            });
        }
    }
}
