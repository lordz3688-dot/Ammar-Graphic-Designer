<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Offer;
use App\Models\Project;
use App\Models\ProjectImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\File;

class AdminController extends Controller
{
    public function login()
    {
        if (session('admin_id')) {
            return redirect()->route('admin.dashboard');
        }

        return view('admin.login');
    }

    public function authenticate(Request $request)
    {
        $data = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $admin = DB::table('admins')->where('username', $data['username'])->first();

        if (! $admin || ! Hash::check($data['password'], $admin->password)) {
            return back()->withErrors(['login' => 'بيانات الدخول غير صحيحة.'])->withInput();
        }

        session(['admin_id' => $admin->id, 'admin_name' => $admin->username]);

        return redirect()->route('admin.dashboard');
    }

    public function dashboard()
    {
        $this->ensureProjectCommentsColumn();

        if (! session('admin_id')) {
            return redirect()->route('admin.login');
        }

        $settings = DB::table('settings')->pluck('value', 'key')->all();

        // Decode experiences and tools settings safely
        $settings['experiences'] = json_decode($settings['experiences_json'] ?? '[]', true);
        $settings['tools'] = json_decode($settings['tools_json'] ?? '[]', true);

        return view('admin.dashboard', [
            'projects' => Project::query()->with('images')->withCount('images')->latest('created_at')->get(),
            'offers' => Offer::query()->get(),
            'comments' => Comment::query()->with('project')->latest('created_at')->get(),
            'approvedCount' => Comment::query()->where('status', 'approved')->count(),
            'settings' => $settings,
        ]);
    }

    public function approveComment(Comment $comment)
    {
        $this->authorizeAdmin();

        $comment->update(['status' => 'approved']);

        return back()->with('message', 'تم اعتماد التعليق.');
    }

    public function deleteComment(Comment $comment)
    {
        $this->authorizeAdmin();

        $comment->delete();

        return back()->with('message', 'تم حذف التعليق.');
    }

    public function logout()
    {
        session()->forget(['admin_id', 'admin_name']);

        return redirect()->route('admin.login');
    }

    // PROJECTS CRUD
    public function storeProject(Request $request)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'category' => ['nullable', 'string', 'max:100'],
            'images' => ['required', 'array'],
            'images.*' => ['image', 'max:10240'], // max 10MB per image
            'cover_index' => ['nullable', 'integer'],
        ]);

        $uploadedPaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('photo'), $filename);
                $path = 'photo/' . $filename;
                $uploadedPaths[] = $path;
                if (File::isDirectory(base_path('photo'))) {
                    File::copy(public_path($path), base_path($path));
                }
            }
        }

        $coverIndex = (int) $request->input('cover_index', 0);
        $thumbnailPath = $uploadedPaths[$coverIndex] ?? ($uploadedPaths[0] ?? '');

        $project = Project::create([
            'title' => $data['title'],
            'description' => $data['description'] ?? '',
            'category' => $data['category'] ?? '',
            'thumbnail' => $thumbnailPath,
            'created_at' => now(),
        ]);

        // Save remaining images in project_images
        foreach ($uploadedPaths as $index => $path) {
            if ($index !== $coverIndex) {
                $project->images()->create([
                    'image_path' => $path,
                ]);
            }
        }

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'تم إضافة العمل بنجاح.',
                'redirect' => route('admin.dashboard'),
            ]);
        }

        return redirect()->route('admin.dashboard')->with('message', 'تم إضافة العمل بنجاح.');
    }

    public function updateProject(Request $request, Project $project)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'category' => ['nullable', 'string', 'max:100'],
            'deleted_paths' => ['nullable', 'array'],
            'cover_source' => ['required', 'string', 'in:existing,new'],
            'cover_val' => ['required', 'string'],
            'images' => ['nullable', 'array'],
            'images.*' => ['image', 'max:10240'],
        ]);

        $deletedPaths = $request->input('deleted_paths', []);

        // Delete physical files
        foreach ($deletedPaths as $path) {
            if ($path && File::exists(public_path($path))) {
                File::delete(public_path($path));
            }
            if ($path && File::exists(base_path($path))) {
                File::delete(base_path($path));
            }
        }

        // Upload new files
        $newPaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('photo'), $filename);
                $path = 'photo/' . $filename;
                $newPaths[] = $path;
                if (File::isDirectory(base_path('photo'))) {
                    File::copy(public_path($path), base_path($path));
                }
            }
        }

        // Gather remaining existing paths
        $allExisting = collect([$project->thumbnail])->merge($project->images->pluck('image_path'))->filter()->unique()->values()->toArray();
        $remainingExisting = array_values(array_diff($allExisting, $deletedPaths));

        // Determine new cover path
        $coverSource = $request->input('cover_source');
        $coverVal = $request->input('cover_val');
        $newCoverPath = '';

        if ($coverSource === 'new') {
            $newCoverPath = $newPaths[(int)$coverVal] ?? '';
        } else {
            $newCoverPath = $coverVal; // This is the path of an existing image
        }

        // If the cover path is empty, fallback to the first remaining image or first new image
        if (empty($newCoverPath)) {
            $newCoverPath = $remainingExisting[0] ?? ($newPaths[0] ?? '');
        }

        // All active paths
        $allActivePaths = array_merge($remainingExisting, $newPaths);
        // Gallery paths (all active paths except the new cover)
        $galleryPaths = array_values(array_filter($allActivePaths, fn($p) => $p !== $newCoverPath));

        $project->update([
            'title' => $data['title'],
            'description' => $data['description'] ?? '',
            'category' => $data['category'] ?? '',
            'thumbnail' => $newCoverPath,
        ]);

        // Clean up database gallery associations
        $project->images()->delete();

        // Re-insert remaining gallery associations
        foreach ($galleryPaths as $p) {
            $project->images()->create([
                'image_path' => $p,
            ]);
        }

        if ($request->ajax() || $request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'تم تعديل العمل بنجاح.',
                'redirect' => route('admin.dashboard'),
            ]);
        }

        return redirect()->route('admin.dashboard')->with('message', 'تم تعديل العمل بنجاح.');
    }

    public function deleteProject(Project $project)
    {
        $this->authorizeAdmin();

        // Delete thumbnail
        if ($project->thumbnail && File::exists(public_path($project->thumbnail))) {
            File::delete(public_path($project->thumbnail));
        }
        if ($project->thumbnail && File::exists(base_path($project->thumbnail))) {
            File::delete(base_path($project->thumbnail));
        }

        // Delete project images
        foreach ($project->images as $img) {
            if ($img->image_path && File::exists(public_path($img->image_path))) {
                File::delete(public_path($img->image_path));
            }
            if ($img->image_path && File::exists(base_path($img->image_path))) {
                File::delete(base_path($img->image_path));
            }
            $img->delete();
        }

        // Delete comments
        $project->comments()->delete();

        $project->delete();

        return back()->with('message', 'تم حذف العمل بالكامل.');
    }

    // PROJECT IMAGES CRUD
    public function uploadProjectImages(Request $request, Project $project)
    {
        $this->authorizeAdmin();

        $request->validate([
            'images' => ['required', 'array'],
            'images.*' => ['image', 'max:5120'],
        ]);

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('photo'), $filename);
                $imagePath = 'photo/' . $filename;
                $project->images()->create([
                    'image_path' => $imagePath,
                ]);
                if (File::isDirectory(base_path('photo'))) {
                    File::copy(public_path($imagePath), base_path($imagePath));
                }
            }
        }

        return back()->with('message', 'تم إضافة الصور للمعرض بنجاح.');
    }

    public function deleteProjectImage(ProjectImage $image)
    {
        $this->authorizeAdmin();

        if ($image->image_path && File::exists(public_path($image->image_path))) {
            File::delete(public_path($image->image_path));
        }
        if ($image->image_path && File::exists(base_path($image->image_path))) {
            File::delete(base_path($image->image_path));
        }

        $image->delete();

        return back()->with('message', 'تم حذف الصورة من المعرض.');
    }

    // OFFERS CRUD
    public function storeOffer(Request $request)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'price' => ['required', 'string', 'max:100'],
            'description' => ['required', 'string'],
            'icon' => ['nullable', 'string', 'max:100'],
        ]);

        Offer::create([
            'title' => $data['title'],
            'price' => $data['price'],
            'description' => $data['description'],
            'icon' => $data['icon'] ?? 'fa-solid fa-wand-magic-sparkles',
        ]);

        return back()->with('message', 'تم إضافة الخدمة/العرض بنجاح.');
    }

    public function updateOffer(Request $request, Offer $offer)
    {
        $this->authorizeAdmin();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'price' => ['required', 'string', 'max:100'],
            'description' => ['required', 'string'],
            'icon' => ['nullable', 'string', 'max:100'],
        ]);

        $offer->update([
            'title' => $data['title'],
            'price' => $data['price'],
            'description' => $data['description'],
            'icon' => $data['icon'] ?? 'fa-solid fa-wand-magic-sparkles',
        ]);

        return back()->with('message', 'تم تعديل الخدمة/العرض بنجاح.');
    }

    public function deleteOffer(Offer $offer)
    {
        $this->authorizeAdmin();

        $offer->delete();

        return back()->with('message', 'تم حذف الخدمة/العرض.');
    }

    // GENERAL SETTINGS UPDATE
    public function updateSettings(Request $request)
    {
        $this->authorizeAdmin();

        // 1. Basic properties
        $inputs = $request->only([
            'hero_title',
            'hero_eyebrow',
            'hero_description',
            'experience_years',
            'adobe_tools',
            'accent_text',
            'about_bio',
            'about_summary',
            'whatsapp_url',
            'behance_url',
            'twitter_url',
        ]);

        // 2. Experiences JSON
        $expTitles = $request->input('exp_title', []);
        $expDescs = $request->input('exp_desc', []);
        $experiences = [];
        for ($i = 0; $i < count($expTitles); $i++) {
            if (!empty($expTitles[$i])) {
                $experiences[] = [
                    'title' => $expTitles[$i],
                    'desc' => $expDescs[$i] ?? '',
                ];
            }
        }
        $inputs['experiences_json'] = json_encode($experiences, JSON_UNESCAPED_UNICODE);

        // 3. Tools JSON
        $toolNames = $request->input('tool_name', []);
        $toolDescs = $request->input('tool_desc', []);
        $toolIcons = $request->input('tool_icon', []);
        $tools = [];
        for ($i = 0; $i < count($toolNames); $i++) {
            if (!empty($toolNames[$i])) {
                $tools[] = [
                    'name' => $toolNames[$i],
                    'desc' => $toolDescs[$i] ?? '',
                    'icon' => $toolIcons[$i] ?? 'fa-solid fa-layer-group',
                ];
            }
        }
        $inputs['tools_json'] = json_encode($tools, JSON_UNESCAPED_UNICODE);

        // 4. Photo upload
        if ($request->hasFile('my_photo')) {
            $request->validate([
                'my_photo' => ['image', 'max:5120'],
            ]);

            $oldPhoto = DB::table('settings')->where('key', 'my_photo')->value('value');
            if ($oldPhoto && $oldPhoto !== 'photo/myphoto.png' && File::exists(public_path($oldPhoto))) {
                File::delete(public_path($oldPhoto));
            }
            if ($oldPhoto && $oldPhoto !== 'photo/myphoto.png' && File::exists(base_path($oldPhoto))) {
                File::delete(base_path($oldPhoto));
            }

            $file = $request->file('my_photo');
            $filename = 'profile_' . time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('photo'), $filename);
            $inputs['my_photo'] = 'photo/' . $filename;
            if (File::isDirectory(base_path('photo'))) {
                File::copy(public_path($inputs['my_photo']), base_path($inputs['my_photo']));
            }
        }

        // Save to DB
        foreach ($inputs as $key => $val) {
            DB::table('settings')->updateOrInsert(['key' => $key], ['value' => $val]);
        }

        return back()->with('message', 'تم تحديث إعدادات الموقع بنجاح.');
    }

    private function authorizeAdmin(): void
    {
        abort_unless(session('admin_id'), 403);
    }

    private function ensureProjectCommentsColumn(): void
    {
        if (! Schema::hasColumn('comments', 'project_id')) {
            Schema::table('comments', function ($table) {
                $table->integer('project_id')->nullable()->index();
            });
        }
    }
}
