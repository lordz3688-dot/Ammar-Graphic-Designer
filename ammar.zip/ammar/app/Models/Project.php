<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'title',
        'description',
        'category',
        'thumbnail',
        'created_at',
    ];

    public function images()
    {
        return $this->hasMany(ProjectImage::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
}
