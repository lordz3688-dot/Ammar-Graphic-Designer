<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectImage extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'project_id',
        'image_path',
    ];
}
