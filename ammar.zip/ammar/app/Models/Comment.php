<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'project_id',
        'user_name',
        'user_email',
        'user_avatar',
        'comment',
        'rating',
        'status',
        'created_at',
    ];

    public function project()
    {
        return $this->belongsTo(Project::class);
    }
}
