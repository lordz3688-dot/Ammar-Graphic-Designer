<?php

use App\Http\Controllers\PortfolioController;
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PortfolioController::class, 'home'])->name('home');
Route::get('/works', [PortfolioController::class, 'works'])->name('works');
Route::get('/works/{project}', [PortfolioController::class, 'work'])->name('works.show');
Route::post('/works/{project}/comments', [PortfolioController::class, 'storeComment'])->name('works.comments.store');
Route::get('/resume', [PortfolioController::class, 'resume'])->name('resume');
Route::get('/contact', [PortfolioController::class, 'contact'])->name('contact');

Route::get('/admin', [AdminController::class, 'dashboard'])->name('admin.dashboard');
Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard.legacy');
Route::get('/admin/login', [AdminController::class, 'login'])->name('admin.login');
Route::post('/admin/login', [AdminController::class, 'authenticate'])->name('admin.authenticate');
Route::post('/admin/logout', [AdminController::class, 'logout'])->name('admin.logout');

// Comments admin
Route::post('/admin/comments/{comment}/approve', [AdminController::class, 'approveComment'])->name('admin.comments.approve');
Route::delete('/admin/comments/{comment}', [AdminController::class, 'deleteComment'])->name('admin.comments.delete');

// Projects admin CRUD
Route::post('/admin/projects', [AdminController::class, 'storeProject'])->name('admin.projects.store');
Route::post('/admin/projects/{project}', [AdminController::class, 'updateProject'])->name('admin.projects.update');
Route::delete('/admin/projects/{project}', [AdminController::class, 'deleteProject'])->name('admin.projects.delete');

// Additional project images CRUD
Route::post('/admin/projects/{project}/images', [AdminController::class, 'uploadProjectImages'])->name('admin.projects.images.store');
Route::delete('/admin/project-images/{image}', [AdminController::class, 'deleteProjectImage'])->name('admin.projects.images.delete');

// Offers admin CRUD
Route::post('/admin/offers', [AdminController::class, 'storeOffer'])->name('admin.offers.store');
Route::post('/admin/offers/{offer}', [AdminController::class, 'updateOffer'])->name('admin.offers.update');
Route::delete('/admin/offers/{offer}', [AdminController::class, 'deleteOffer'])->name('admin.offers.delete');

// General settings admin
Route::post('/admin/settings', [AdminController::class, 'updateSettings'])->name('admin.settings.update');

