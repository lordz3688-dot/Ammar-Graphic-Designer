<?php $__env->startSection('title', 'عمار | مصمم جرافيك'); ?>

<?php $__env->startSection('content'); ?>
<section class="shell hero">
    <div>
        <div class="eyebrow"><?php echo e($settings['hero_eyebrow'] ?? 'مصمم جرافيك بخبرة 4 سنوات'); ?></div>
        <h1><?php echo $settings['hero_title'] ?? 'أحوّل الأفكار إلى <span class="gradient-text">تجارب بصرية</span> واضحة ومؤثرة.'; ?></h1>
        <p class="lead">
            <?php echo e($settings['hero_description'] ?? 'أصمم هويات بصرية، مواد تسويقية، ومنشورات رقمية تجمع بين الجمال والهدف العملي. أتعامل مع كل مشروع كرسالة تحتاج إلى شكل ذكي وصوت بصري مميز.'); ?>

        </p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="<?php echo e(route('works')); ?>"><i class="fa-solid fa-images"></i> مشاهدة الأعمال</a>
            <a class="btn btn-ghost" href="<?php echo e(route('resume')); ?>"><i class="fa-solid fa-file-lines"></i> السيرة الذاتية</a>
        </div>
        <div class="stats">
            <div class="stat"><strong><?php echo e($settings['experience_years'] ?? '4+'); ?></strong><span>سنوات خبرة</span></div>
            <div class="stat"><strong><?php echo e($settings['adobe_tools'] ?? '3'); ?></strong><span>أدوات Adobe رئيسية</span></div>
            <div class="stat"><strong><?php echo e($settings['accent_text'] ?? '100%'); ?></strong><span>اهتمام بالتفاصيل</span></div>
        </div>
    </div>
    <div class="portrait-wrap">
        <img class="portrait" src="<?php echo e(asset($settings['my_photo'] ?? 'photo/myphoto.png')); ?>" alt="صورة عمار">
    </div>
</section>

<section class="shell section">
    <div class="section-head">
        <h2>خدمات التصميم</h2>
        <p>حلول بصرية للشركات والأفراد، من بناء الهوية وحتى تجهيز المواد الرقمية والمطبوعة.</p>
    </div>
    <div class="grid-3">
        <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="card">
                <i class="<?php echo e($offer->icon ?: 'fa-solid fa-wand-magic-sparkles'); ?>"></i>
                <h3><?php echo e($offer->title); ?></h3>
                <p><?php echo e($offer->description); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <article class="card"><i class="fa-solid fa-pen-nib"></i><h3>تصميم الهوية البصرية</h3><p>شعارات، ألوان، خطوط، وتطبيقات تعكس شخصية المشروع بوضوح.</p></article>
            <article class="card"><i class="fa-solid fa-hashtag"></i><h3>تصاميم السوشيال ميديا</h3><p>منشورات احترافية للحملات، العروض، والمحتوى اليومي.</p></article>
            <article class="card"><i class="fa-solid fa-book-open"></i><h3>المطبوعات والملفات الرقمية</h3><p>بروفايلات، مجلات، كتالوجات، ومواد تسويقية جاهزة للنشر.</p></article>
        <?php endif; ?>
    </div>
</section>

<?php if(isset($comments) && $comments->count() > 0): ?>
<section class="shell section" style="border-top: 1px solid var(--line); margin-top: 40px; padding-top: 60px;">
    <div class="section-head">
        <h2>آراء العملاء</h2>
        <p>ماذا يقول العملاء والزوار عن جودة الأعمال والتعامل.</p>
    </div>
    <div class="grid-3">
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="card" style="min-height: auto;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <strong style="font-size: 1.1rem; color: #fff;"><?php echo e($comment->user_name); ?></strong>
                    <span style="color: var(--gold); font-size: 0.9rem;">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fa-<?php echo e($i <= $comment->rating ? 'solid' : 'regular'); ?> fa-star"></i>
                        <?php endfor; ?>
                    </span>
                </div>
                <p style="color: var(--muted); line-height: 1.8; font-size: 0.95rem;">
                    "<?php echo e($comment->comment); ?>"
                </p>
                <?php if($comment->project): ?>
                    <div style="margin-top: 14px; font-size: 0.85rem; color: var(--accent); font-weight: 800;">
                        <i class="fa-solid fa-link"></i> عمل مرتبط: <a href="<?php echo e(route('works.show', $comment->project)); ?>" style="text-decoration: underline; color: inherit;"><?php echo e($comment->project->title); ?></a>
                    </div>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ammar\resources\views/home.blade.php ENDPATH**/ ?>