<?php $__env->startSection('title', 'عمار | دخول لوحة التحكم'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-login shell">
    <div class="admin-login-card">
        <div class="eyebrow">لوحة التحكم</div>
        <h1>تسجيل دخول المشرف</h1>
        <p>أدخل بيانات الإدارة للوصول إلى الأعمال والتعليقات.</p>

        <?php if($errors->has('login')): ?>
            <div class="admin-alert"><?php echo e($errors->first('login')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('admin.authenticate')); ?>">
            <?php echo csrf_field(); ?>
            <label for="username">اسم المستخدم</label>
            <input id="username" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

            <label for="password">كلمة المرور</label>
            <input id="password" name="password" type="password" required>

            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-lock"></i> دخول</button>
        </form>
    </div>
</section>

<style>
    .admin-login {
        min-height: calc(100vh - 160px);
        display: grid;
        place-items: center;
        padding: 60px 0;
    }

    .admin-login-card {
        width: min(520px, 100%);
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 16px;
        box-shadow: var(--shadow);
        padding: clamp(24px, 4vw, 42px);
    }

    .admin-login-card h1 {
        font-size: clamp(2rem, 5vw, 3rem);
        line-height: 1.25;
    }

    .admin-login-card p {
        color: var(--muted);
        line-height: 1.8;
    }

    .admin-login-card label {
        display: block;
        margin: 16px 0 8px;
        font-weight: 900;
    }

    .admin-login-card input {
        width: 100%;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.03);
        color: #fff;
        padding: 14px;
        font-family: inherit;
        font-size: 1rem;
    }

    .admin-login-card .btn {
        width: 100%;
        margin-top: 20px;
    }

    .admin-alert {
        background: rgba(255, 107, 53, 0.12);
        color: var(--accent);
        border: 1px solid rgba(255, 107, 53, 0.25);
        padding: 12px;
        border-radius: 8px;
        font-weight: 900;
        margin: 16px 0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ammar\resources\views/admin/login.blade.php ENDPATH**/ ?>