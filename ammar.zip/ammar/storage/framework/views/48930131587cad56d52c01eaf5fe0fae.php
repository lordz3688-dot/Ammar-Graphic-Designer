<?php $__env->startSection('title', 'عمار | لوحة التحكم'); ?>

<?php $__env->startSection('content'); ?>
<section class="shell page-hero admin-hero">
    <div>
        <div class="eyebrow">لوحة التحكم</div>
        <h1>إدارة محتوى الموقع بالكامل.</h1>
        <p class="lead">تعديل الأعمال، الخدمات، نصوص الموقع، الروابط، وإدارة تعليقات وتقييمات العملاء.</p>
    </div>
    <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-ghost" type="submit"><i class="fa-solid fa-right-from-bracket"></i> تسجيل الخروج</button>
    </form>
</section>

<?php if(session('message')): ?>
    <div class="shell admin-notice"><?php echo e(session('message')); ?></div>
<?php endif; ?>

<section class="shell admin-tabs-container">
    <!-- أزرار التبويبات -->
    <div class="admin-tabs">
        <button class="tab-btn active" onclick="openTab(event, 'overview')"><i class="fa-solid fa-chart-line"></i> نظرة عامة</button>
        <button class="tab-btn" onclick="openTab(event, 'projects')"><i class="fa-solid fa-images"></i> معرض الأعمال</button>
        <button class="tab-btn" onclick="openTab(event, 'offers')"><i class="fa-solid fa-wand-magic-sparkles"></i> الخدمات</button>
        <button class="tab-btn" onclick="openTab(event, 'settings')"><i class="fa-solid fa-gears"></i> إعدادات الموقع</button>
        <button class="tab-btn" onclick="openTab(event, 'comments')"><i class="fa-solid fa-comments"></i> التعليقات</button>
    </div>

    <!-- التبويب 1: نظرة عامة -->
    <div id="overview" class="tab-content active">
        <div class="admin-stats">
            <article><strong><?php echo e($projects->count()); ?></strong><span>الأعمال المضافة</span></article>
            <article><strong><?php echo e($offers->count()); ?></strong><span>الخدمات والعروض</span></article>
            <article><strong><?php echo e($comments->count()); ?></strong><span>إجمالي التعليقات</span></article>
            <article><strong><?php echo e($approvedCount); ?></strong><span>تعليقات معتمدة</span></article>
        </div>

        <div class="admin-panel mt-4">
            <div class="panel-head">
                <h2>التعليقات المعلقة (بحاجة لاعتماد)</h2>
            </div>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>العمل</th>
                            <th>التقييم</th>
                            <th>التعليق</th>
                            <th>إجراء</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $pendingComments = $comments->where('status', 'pending'); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $pendingComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($comment->user_name); ?></td>
                                <td><?php echo e($comment->project?->title ?: 'عام'); ?></td>
                                <td class="stars">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa-<?php echo e($i <= $comment->rating ? 'solid' : 'regular'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </td>
                                <td><?php echo e($comment->comment); ?></td>
                                <td>
                                    <div class="admin-actions">
                                        <form method="POST" action="<?php echo e(route('admin.comments.approve', $comment)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn-success">اعتماد</button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('admin.comments.delete', $comment)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="danger" type="submit">حذف</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5">لا توجد تعليقات معلقة حالياً. جميع التعليقات معتمدة!</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- التبويب 2: إدارة الأعمال -->
    <div id="projects" class="tab-content">
        <div class="admin-split">
            <!-- قائمة الأعمال -->
            <div class="admin-panel">
                <div class="panel-head">
                    <h2>الأعمال الحالية</h2>
                    <span><?php echo e($projects->count()); ?> عمل</span>
                </div>
                <div class="admin-table-wrap">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>العنوان</th>
                                <th>التصنيف</th>
                                <th>الصور الإضافية</th>
                                <th>التحكم</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><img src="<?php echo e(asset($project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px;"></td>
                                    <td><?php echo e($project->title); ?></td>
                                    <td><?php echo e($project->category ?: 'غير مصنف'); ?></td>
                                    <td><?php echo e($project->images->count()); ?> صور إضافية</td>
                                    <td>
                                        <div class="admin-actions">
                                            <button type="button" class="btn-info" onclick="editProject('<?php echo e($project->id); ?>', '<?php echo e(addslashes($project->title)); ?>', '<?php echo e(addslashes($project->category)); ?>', '<?php echo e(addslashes($project->description)); ?>', '<?php echo e(route('admin.projects.update', $project)); ?>', '<?php echo e($project->thumbnail); ?>', '<?php echo e(base64_encode(json_encode($project->images))); ?>')"><i class="fa-solid fa-pen"></i> تعديل</button>
                                            <button type="button" class="btn-warning" onclick="manageImages('<?php echo e($project->id); ?>', '<?php echo e(addslashes($project->title)); ?>', '<?php echo e(route('admin.projects.images.store', $project)); ?>', <?php echo json_encode($project->images); ?>)"><i class="fa-solid fa-images"></i> الصور</button>
                                            <form method="POST" action="<?php echo e(route('admin.projects.delete', $project)); ?>" onsubmit="return confirm('هل أنت متأكد من حذف هذا العمل بالكامل مع كافة صوره وتعليقاته؟')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5">لا توجد أعمال مضافة حالياً.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- إضافة/تعديل عمل -->
            <div class="admin-sidebar-panels">
                <div class="admin-panel" id="project-form-container">
                    <h2 id="project-form-title">إضافة عمل جديد</h2>
                    <form id="project-main-form" method="POST" action="<?php echo e(route('admin.projects.store')); ?>" enctype="multipart/form-data" class="admin-form">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Inputs for tracking project edits, cover selection index, and deleted images -->
                        <input type="hidden" id="edit_project_id" name="project_id" value="">
                        <input type="hidden" id="cover_source" name="cover_source" value="new">
                        <input type="hidden" id="cover_val" name="cover_val" value="0">
                        <input type="hidden" id="cover_index" name="cover_index" value="0">
                        <div id="deleted-paths-inputs"></div>

                        <div class="form-group">
                            <label for="project_title">عنوان العمل</label>
                            <input type="text" id="project_title" name="title" required placeholder="مثال: هوية عطور فاخرة">
                        </div>

                        <div class="form-group">
                            <label for="project_category">تصنيف العمل</label>
                            <input type="text" id="project_category" name="category" placeholder="مثال: هوية بصرية، سوشيال ميديا">
                        </div>

                        <div class="form-group">
                            <label for="project_description">وصف العمل</label>
                            <textarea id="project_description" name="description" rows="4" placeholder="اكتب تفاصيل الفكرة والبرامج المستخدمة..."></textarea>
                        </div>

                        <div class="form-group">
                            <label id="upload-label" for="project_images_input">صور العمل (اختر صورة أو أكثر، وحدد صورة الغلاف بالضغط عليها)</label>
                            <input type="file" id="project_images_input" name="images[]" multiple accept="image/*">
                            
                            <!-- Grid for previews -->
                            <div id="project-images-preview-grid" class="project-images-preview-grid mt-2">
                                <div style="grid-column: 1/-1; color: var(--muted); text-align: center; line-height: 80px;">لا توجد صور محددة حالياً.</div>
                            </div>
                        </div>

                        <!-- Real-time upload progress details -->
                        <div id="upload-progress-container" class="upload-progress-container mt-4" style="display: none;">
                            <div class="progress-details">
                                <span id="upload-status-text">جاري الرفع...</span>
                                <span id="upload-percentage-text">0%</span>
                            </div>
                            <div class="progress-bar-track">
                                <div id="upload-progress-bar" class="progress-bar-fill"></div>
                            </div>
                            <div class="progress-meta mt-2">
                                <span id="upload-bytes-text">0 MB / 0 MB</span>
                                <span id="upload-time-text">الوقت المتبقي: --</span>
                            </div>
                        </div>

                        <div class="form-buttons">
                            <button type="submit" id="submit-project-btn" class="btn btn-primary" style="width: 100%;">حفظ العمل</button>
                            <button type="button" id="cancel-project-edit" class="btn btn-ghost" style="width: 100%; display: none;" onclick="resetProjectForm()">إلغاء التعديل</button>
                        </div>
                    </form>
                </div>

                <!-- لوحة إدارة الصور الإضافية للعمل -->
                <div class="admin-panel mt-4" id="gallery-form-container" style="display: none;">
                    <h2>الصور الإضافية لعمل: <span id="gallery-project-title" style="color: var(--gold);"></span></h2>
                    
                    <!-- رفع صور إضافية -->
                    <form id="gallery-upload-form" method="POST" action="" enctype="multipart/form-data" class="admin-form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="gallery_images">اختر صور لرفعها للمعرض (يمكن اختيار عدة صور)</label>
                            <input type="file" id="gallery_images" name="images[]" multiple accept="image/*" required>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%; margin-bottom: 16px;">رفع الصور</button>
                    </form>

                    <!-- المعرض المصغر للصور الإضافية وحذفها -->
                    <label>الصور المرفوعة حالياً:</label>
                    <div id="gallery-thumbs-grid" class="gallery-thumbs-grid">
                        <!-- يتم ملؤه عبر جافاسكريبت -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- التبويب 3: إدارة الخدمات والعروض -->
    <div id="offers" class="tab-content">
        <div class="admin-split">
            <!-- قائمة العروض -->
            <div class="admin-panel">
                <div class="panel-head">
                    <h2>الخدمات والعروض المضافة</h2>
                    <span><?php echo e($offers->count()); ?> عرض</span>
                </div>
                <div class="admin-table-wrap">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>الأيقونة</th>
                                <th>العنوان</th>
                                <th>السعر</th>
                                <th>الوصف</th>
                                <th>التحكم</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><i class="<?php echo e($offer->icon ?: 'fa-solid fa-wand-magic-sparkles'); ?>" style="font-size: 1.5rem; color: var(--accent);"></i></td>
                                    <td><?php echo e($offer->title); ?></td>
                                    <td><?php echo e($offer->price); ?></td>
                                    <td><?php echo e($offer->description); ?></td>
                                    <td>
                                        <div class="admin-actions">
                                            <button type="button" class="btn-info" onclick="editOffer('<?php echo e($offer->id); ?>', '<?php echo e(addslashes($offer->title)); ?>', '<?php echo e(addslashes($offer->price)); ?>', '<?php echo e(addslashes($offer->description)); ?>', '<?php echo e(addslashes($offer->icon)); ?>', '<?php echo e(route('admin.offers.update', $offer)); ?>')"><i class="fa-solid fa-pen"></i></button>
                                            <form method="POST" action="<?php echo e(route('admin.offers.delete', $offer)); ?>" onsubmit="return confirm('هل تريد حذف هذه الخدمة؟')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="danger" type="submit"><i class="fa-solid fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5">لا توجد خدمات مضافة حالياً.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- إضافة/تعديل عرض -->
            <div class="admin-panel">
                <h2 id="offer-form-title">إضافة خدمة/عرض جديد</h2>
                <form id="offer-main-form" method="POST" action="<?php echo e(route('admin.offers.store')); ?>" class="admin-form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="offer_title">عنوان الخدمة</label>
                        <input type="text" id="offer_title" name="title" required placeholder="مثال: تصميم هوية بصرية كاملة">
                    </div>

                    <div class="form-group">
                        <label for="offer_price">سعر الخدمة أو التكلفة التقريبية</label>
                        <input type="text" id="offer_price" name="price" required placeholder="مثال: $200 أو يبدأ من $150">
                    </div>

                    <div class="form-group">
                        <label for="offer_icon">كود أيقونة FontAwesome</label>
                        <input type="text" id="offer_icon" name="icon" placeholder="مثال: fa-solid fa-pen-nib">
                    </div>

                    <div class="form-group">
                        <label for="offer_description">وصف الخدمة والمميزات</label>
                        <textarea id="offer_description" name="description" rows="4" required placeholder="اكتب تفاصيل الخدمة وما تقدمه للعميل..."></textarea>
                    </div>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-primary" style="width: 100%;">حفظ الخدمة</button>
                        <button type="button" id="cancel-offer-edit" class="btn btn-ghost" style="width: 100%; display: none;" onclick="resetOfferForm()">إلغاء التعديل</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- التبويب 4: إعدادات الموقع بالكامل -->
    <div id="settings" class="tab-content">
        <form method="POST" action="<?php echo e(route('admin.settings.update')); ?>" enctype="multipart/form-data" class="admin-panel admin-form">
            <?php echo csrf_field(); ?>
            <h2>تعديل نصوص وروابط الموقع بالكامل</h2>
            
            <div class="admin-settings-grid">
                <!-- قسم الهيرو في الصفحة الرئيسية -->
                <fieldset class="settings-fieldset">
                    <legend>الواجهة الرئيسية (Hero Section)</legend>
                    <div class="form-group">
                        <label for="set_hero_eyebrow">النص التعريفي العلوي</label>
                        <input type="text" id="set_hero_eyebrow" name="hero_eyebrow" value="<?php echo e($settings['hero_eyebrow'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_hero_title">العنوان الرئيسي للموقع (يدعم كود HTML للـ Gradient)</label>
                        <input type="text" id="set_hero_title" name="hero_title" value="<?php echo e($settings['hero_title'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_hero_description">الوصف الرئيسي للموقع</label>
                        <textarea id="set_hero_description" name="hero_description" rows="3"><?php echo e($settings['hero_description'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="set_my_photo">الصورة الشخصية (تحديث)</label>
                        <input type="file" id="set_my_photo" name="my_photo" accept="image/*">
                        <?php if(!empty($settings['my_photo'])): ?>
                            <div class="mt-2 text-center">
                                <img src="<?php echo e(asset($settings['my_photo'])); ?>" alt="Profile Image" style="height: 100px; border-radius: 8px; border: 1px solid var(--line); display: inline-block;">
                            </div>
                        <?php endif; ?>
                    </div>
                </fieldset>

                <!-- الإحصائيات في الصفحة الرئيسية -->
                <fieldset class="settings-fieldset">
                    <legend>عدادات الإحصائيات</legend>
                    <div class="form-group">
                        <label for="set_exp_years">سنوات الخبرة (مثال: +4)</label>
                        <input type="text" id="set_exp_years" name="experience_years" value="<?php echo e($settings['experience_years'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_adobe_tools">عدد برامج Adobe الرئيسية (مثال: 3)</label>
                        <input type="text" id="set_adobe_tools" name="adobe_tools" value="<?php echo e($settings['adobe_tools'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_accent_text">نسبة الاهتمام بالتفاصيل / عبارة التميز (مثال: 100%)</label>
                        <input type="text" id="set_accent_text" name="accent_text" value="<?php echo e($settings['accent_text'] ?? ''); ?>">
                    </div>
                </fieldset>

                <!-- نبذة السيرة الذاتية وروابط السوشيال ميديا -->
                <fieldset class="settings-fieldset">
                    <legend>نبذة السيرة الذاتية والتواصل</legend>
                    <div class="form-group">
                        <label for="set_about_bio">السيرة الذاتية المطولة (في صفحة السيرة الذاتية)</label>
                        <textarea id="set_about_bio" name="about_bio" rows="4"><?php echo e($settings['about_bio'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="set_about_summary">الملخص المهني القصير</label>
                        <textarea id="set_about_summary" name="about_summary" rows="3"><?php echo e($settings['about_summary'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="set_whatsapp">رابط واتساب للتواصل السريع</label>
                        <input type="text" id="set_whatsapp" name="whatsapp_url" value="<?php echo e($settings['whatsapp_url'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_behance">رابط بورتفوليو بيهانس</label>
                        <input type="text" id="set_behance" name="behance_url" value="<?php echo e($settings['behance_url'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="set_twitter">رابط حساب إكس / تويتر</label>
                        <input type="text" id="set_twitter" name="twitter_url" value="<?php echo e($settings['twitter_url'] ?? ''); ?>">
                    </div>
                </fieldset>
            </div>

            <!-- قسم إدارة الخبرات والمهارات بشكل ديناميكي -->
            <fieldset class="settings-fieldset mt-4">
                <legend>الخبرات في السيرة الذاتية (جدول زمني ديناميكي)</legend>
                <div id="experiences-rows" class="dynamic-rows">
                    <?php $__empty_1 = true; $__currentLoopData = $settings['experiences'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dynamic-row" id="exp-row-<?php echo e($index); ?>">
                            <input type="text" name="exp_title[]" value="<?php echo e($exp['title']); ?>" placeholder="اسم الشركة / نوع الخبرة" required>
                            <textarea name="exp_desc[]" rows="2" placeholder="وصف الخبرة والتفاصيل" required><?php echo e($exp['desc']); ?></textarea>
                            <button type="button" class="btn danger" onclick="removeRow('exp-row-<?php echo e($index); ?>')"><i class="fa-solid fa-times"></i></button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="dynamic-row" id="exp-row-default">
                            <input type="text" name="exp_title[]" placeholder="اسم الشركة / نوع الخبرة" required>
                            <textarea name="exp_desc[]" rows="2" placeholder="وصف الخبرة والتفاصيل" required></textarea>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn btn-ghost mt-2" onclick="addExperienceRow()"><i class="fa-solid fa-plus"></i> إضافة خبرة جديدة</button>
            </fieldset>

            <!-- قسم إدارة أدوات التصميم بشكل ديناميكي -->
            <fieldset class="settings-fieldset mt-4">
                <legend>أدوات وبرامج التصميم المتقنة</legend>
                <div id="tools-rows" class="dynamic-rows">
                    <?php $__empty_1 = true; $__currentLoopData = $settings['tools'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="dynamic-row" id="tool-row-<?php echo e($index); ?>">
                            <input type="text" name="tool_name[]" value="<?php echo e($tool['name']); ?>" placeholder="اسم الأداة (مثال: Photoshop)" required>
                            <input type="text" name="tool_icon[]" value="<?php echo e($tool['icon'] ?? 'fa-solid fa-layer-group'); ?>" placeholder="كود أيقونة الأداة" required>
                            <textarea name="tool_desc[]" rows="2" placeholder="وصف استخدامك للأداة" required><?php echo e($tool['desc']); ?></textarea>
                            <button type="button" class="btn danger" onclick="removeRow('tool-row-<?php echo e($index); ?>')"><i class="fa-solid fa-times"></i></button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="dynamic-row" id="tool-row-default">
                            <input type="text" name="tool_name[]" placeholder="اسم الأداة (مثال: Photoshop)" required>
                            <input type="text" name="tool_icon[]" placeholder="كود أيقونة الأداة" required>
                            <textarea name="tool_desc[]" rows="2" placeholder="وصف استخدامك للأداة" required></textarea>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn btn-ghost mt-2" onclick="addToolRow()"><i class="fa-solid fa-plus"></i> إضافة أداة جديدة</button>
            </fieldset>

            <button type="submit" class="btn btn-primary mt-4" style="width: 100%; font-size: 1.15rem; padding: 16px;"><i class="fa-solid fa-check"></i> حفظ كافة التعديلات والإعدادات</button>
        </form>
    </div>

    <!-- التبويب 5: إدارة التعليقات بالكامل -->
    <div id="comments" class="tab-content">
        <div class="admin-panel">
            <div class="panel-head">
                <h2>إدارة كافة التعليقات والتقييمات</h2>
                <span><?php echo e($comments->count()); ?> تعليق</span>
            </div>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>العمل</th>
                            <th>التقييم</th>
                            <th>التعليق</th>
                            <th>الحالة</th>
                            <th>التحكم</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($comment->user_name); ?></td>
                                <td><?php echo e($comment->project?->title ?: 'عام'); ?></td>
                                <td class="stars">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa-<?php echo e($i <= $comment->rating ? 'solid' : 'regular'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </td>
                                <td><?php echo e($comment->comment); ?></td>
                                <td><span class="status <?php echo e($comment->status); ?>"><?php echo e($comment->status === 'approved' ? 'معتمد' : 'معلق'); ?></span></td>
                                <td>
                                    <div class="admin-actions">
                                        <?php if($comment->status !== 'approved'): ?>
                                            <form method="POST" action="<?php echo e(route('admin.comments.approve', $comment)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn-success">اعتماد</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" action="<?php echo e(route('admin.comments.delete', $comment)); ?>" onsubmit="return confirm('هل تريد حذف هذا التعليق نهائياً؟')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="danger" type="submit">حذف</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6">لا توجد تعليقات حتى الآن في قاعدة البيانات.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<style>
    .admin-hero {
        display: flex;
        align-items: end;
        justify-content: space-between;
        gap: 20px;
    }

    .admin-notice {
        background: rgba(34, 186, 161, 0.12);
        color: var(--green);
        border: 1px solid rgba(34, 186, 161, 0.25);
        border-radius: 12px;
        padding: 14px 18px;
        font-weight: 800;
        margin-bottom: 22px;
        text-align: right;
    }

    /* التبويبات */
    .admin-tabs-container {
        margin-top: 20px;
        margin-bottom: 60px;
    }

    .admin-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 24px;
        border-bottom: 1px solid var(--line);
        padding-bottom: 12px;
    }

    .tab-btn {
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid var(--line);
        color: var(--muted);
        border-radius: 8px;
        padding: 12px 18px;
        font-family: inherit;
        font-size: 1rem;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: 0.2s ease;
    }

    .tab-btn:hover {
        background: rgba(255, 107, 53, 0.05);
        color: #fff;
    }

    .tab-btn.active {
        background: var(--accent);
        color: #fff;
        border-color: var(--accent);
        box-shadow: 0 8px 24px rgba(255, 107, 53, 0.25);
    }

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
        animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* كروت إحصائيات */
    .admin-stats {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
        margin-bottom: 24px;
    }

    .admin-stats article {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 12px;
        padding: 20px;
        box-shadow: var(--shadow);
    }

    .admin-stats strong {
        display: block;
        color: var(--accent);
        font-size: 2.2rem;
        margin-bottom: 4px;
    }

    .admin-stats span {
        color: var(--muted);
        font-weight: 800;
    }

    /* الهيكل المنقسم */
    .admin-split {
        display: grid;
        grid-template-columns: 1.2fr .8fr;
        gap: 24px;
        align-items: start;
    }

    .admin-sidebar-panels {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .admin-panel {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        padding: 22px;
        box-shadow: var(--shadow);
        min-width: 0;
    }

    .panel-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
        border-bottom: 1px solid var(--line);
        padding-bottom: 10px;
    }

    .panel-head h2 {
        margin-bottom: 0;
        font-size: 1.45rem;
    }

    .panel-head span {
        color: var(--gold);
        font-weight: 800;
    }

    /* الجداول */
    .admin-table-wrap {
        overflow-x: auto;
        max-width: 100%;
    }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 600px;
        text-align: right;
    }

    .admin-table th,
    .admin-table td {
        border-bottom: 1px solid var(--line);
        padding: 14px 12px;
        vertical-align: middle;
        font-size: 0.98rem;
    }

    .admin-table th {
        color: var(--gold);
        font-weight: 800;
        background: rgba(255, 255, 255, 0.01);
    }

    .admin-table td {
        color: var(--text);
    }

    .stars {
        color: var(--gold);
        white-space: nowrap;
    }

    .status {
        display: inline-flex;
        border-radius: 999px;
        padding: 4px 10px;
        font-size: 0.85rem;
        font-weight: 800;
        background: rgba(34, 186, 161, 0.12);
        color: var(--green);
    }

    .status.pending {
        background: rgba(255, 107, 53, 0.12);
        color: var(--accent);
    }

    .admin-actions {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
    }

    .admin-actions button,
    .admin-actions a {
        border: 0;
        border-radius: 6px;
        padding: 8px 12px;
        font-family: inherit;
        font-weight: 800;
        font-size: 0.88rem;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: 0.2s ease;
    }

    .btn-success {
        background: var(--green);
        color: #fff;
    }

    .btn-success:hover {
        background: #2cd4b9;
    }

    .btn-info {
        background: var(--blue);
        color: #fff;
    }

    .btn-info:hover {
        background: #6bb4ff;
    }

    .btn-warning {
        background: var(--gold);
        color: #090314;
    }

    .btn-warning:hover {
        background: #ffe08c;
    }

    .admin-actions button.danger {
        background: rgba(255, 107, 53, 0.15);
        color: var(--accent);
        border: 1px solid rgba(255, 107, 53, 0.25);
    }

    .admin-actions button.danger:hover {
        background: var(--accent);
        color: #fff;
    }

    /* نماذج الإدخال */
    .admin-form {
        display: grid;
        gap: 16px;
    }

    .form-group {
        display: grid;
        gap: 8px;
    }

    .form-group label {
        font-weight: 800;
        color: var(--gold);
    }

    .admin-form input,
    .admin-form textarea,
    .admin-form select {
        width: 100%;
        border: 1px solid var(--line);
        background: rgba(255, 255, 255, 0.02);
        color: #fff;
        border-radius: 8px;
        padding: 12px 14px;
        font-family: inherit;
        font-size: 0.98rem;
        transition: border-color 0.2s ease;
    }

    .admin-form input:focus,
    .admin-form textarea:focus {
        outline: none;
        border-color: var(--accent);
    }

    .form-buttons {
        display: grid;
        gap: 10px;
        margin-top: 8px;
    }

    /* معرض الصور المصغر */
    .gallery-thumbs-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));
        gap: 10px;
        margin-top: 10px;
    }

    .gallery-thumb-item {
        position: relative;
        border-radius: 6px;
        overflow: hidden;
        border: 1px solid var(--line);
        aspect-ratio: 1/1;
    }

    .gallery-thumb-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .gallery-thumb-item form {
        position: absolute;
        top: 2px;
        right: 2px;
        z-index: 5;
    }

    .gallery-thumb-item button {
        background: rgba(255, 107, 53, 0.85);
        color: #fff;
        border: 0;
        width: 22px;
        height: 22px;
        border-radius: 4px;
        display: grid;
        place-items: center;
        font-size: 0.75rem;
        cursor: pointer;
    }

    /* إعدادات شبكة الحقول */
    .admin-settings-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .settings-fieldset {
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 20px;
        background: rgba(255, 255, 255, 0.01);
        display: grid;
        gap: 14px;
        align-content: start;
    }

    .settings-fieldset legend {
        color: var(--accent);
        font-weight: 900;
        padding: 0 10px;
        font-size: 1.1rem;
    }

    /* صفوف ديناميكية */
    .dynamic-rows {
        display: grid;
        gap: 12px;
    }

    .dynamic-row {
        display: flex;
        gap: 10px;
        align-items: flex-start;
        background: rgba(255, 255, 255, 0.01);
        padding: 10px;
        border: 1px solid var(--line);
        border-radius: 8px;
    }

    .dynamic-row input {
        flex: 1;
        min-width: 0;
    }

    .dynamic-row textarea {
        flex: 2;
        min-width: 0;
    }

    .dynamic-row button {
        align-self: center;
        padding: 10px;
        height: 44px;
        width: 44px;
        display: grid;
        place-items: center;
    }

    .mt-4 { margin-top: 24px; }
    .mt-2 { margin-top: 12px; }

    @media (max-width: 900px) {
        .admin-hero {
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: 16px;
        }

        .admin-stats {
            grid-template-columns: repeat(2, 1fr);
        }

        .admin-split {
            grid-template-columns: 1fr;
        }

        .admin-settings-grid {
            grid-template-columns: 1fr;
        }

        .dynamic-row {
            flex-direction: column;
            align-items: stretch;
            gap: 10px;
        }

        .dynamic-row input,
        .dynamic-row textarea {
            width: 100%;
            flex: none;
        }

        .dynamic-row button {
            width: 100% !important;
            height: 40px;
            margin-top: 4px;
        }
    }

    @media (max-width: 560px) {
        .admin-stats {
            grid-template-columns: 1fr;
        }

        .admin-tabs {
            justify-content: center;
        }

        .tab-btn {
            width: 100%;
            justify-content: center;
        }
    }

    /* Preview Grid for uploading images and selecting cover */
    .project-images-preview-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
        gap: 12px;
        background: rgba(0, 0, 0, 0.2);
        border: 1px dashed var(--line);
        border-radius: 8px;
        padding: 12px;
        min-height: 80px;
    }

    .preview-card {
        position: relative;
        aspect-ratio: 1/1;
        border-radius: 6px;
        overflow: hidden;
        border: 2px solid transparent;
        cursor: pointer;
        transition: border-color 0.2s ease, transform 0.2s ease;
        background: rgba(255, 255, 255, 0.02);
    }

    .preview-card:hover {
        transform: scale(1.03);
    }

    .preview-card.is-cover {
        border-color: var(--gold);
        box-shadow: 0 0 12px rgba(255, 209, 102, 0.4);
    }

    .preview-card img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .preview-badge {
        position: absolute;
        bottom: 4px;
        left: 4px;
        right: 4px;
        background: rgba(9, 3, 20, 0.85);
        color: #fff;
        font-size: 0.75rem;
        font-weight: 800;
        text-align: center;
        padding: 3px 0;
        border-radius: 4px;
        backdrop-filter: blur(4px);
        opacity: 0;
        transition: opacity 0.2s ease;
    }

    .preview-card:hover .preview-badge,
    .preview-card.is-cover .preview-badge {
        opacity: 1;
    }

    .preview-card.is-cover .preview-badge {
        background: var(--gold);
        color: #090314;
    }

    .preview-delete-btn {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        border-radius: 4px;
        background: rgba(255, 107, 53, 0.85);
        color: #fff;
        border: 0;
        cursor: pointer;
        display: grid;
        place-items: center;
        font-size: 0.75rem;
        transition: background 0.2s ease;
        z-index: 5;
    }

    .preview-delete-btn:hover {
        background: #ff521a;
    }

    /* Upload Progress Bar */
    .upload-progress-container {
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 16px;
    }

    .progress-details {
        display: flex;
        justify-content: space-between;
        font-weight: 800;
        margin-bottom: 8px;
    }

    #upload-status-text {
        color: var(--accent);
    }

    #upload-percentage-text {
        color: #fff;
    }

    .progress-bar-track {
        height: 10px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 999px;
        overflow: hidden;
        border: 1px solid var(--line);
    }

    .progress-bar-fill {
        height: 100%;
        width: 0%;
        background: linear-gradient(90deg, var(--accent), var(--gold));
        box-shadow: 0 0 10px rgba(255, 107, 53, 0.5);
        border-radius: 999px;
        transition: width 0.1s linear;
    }

    .progress-meta {
        display: flex;
        justify-content: space-between;
        font-size: 0.82rem;
        color: var(--muted);
        font-weight: 700;
    }
</style>

<script>
    // تفعيل التبويبات
    function openTab(evt, tabName) {
        // إخفاء المحتوى
        const tabContents = document.querySelectorAll(".tab-content");
        tabContents.forEach(content => content.classList.remove("active"));

        // إلغاء تفعيل الأزرار
        const tabBtns = document.querySelectorAll(".tab-btn");
        tabBtns.forEach(btn => btn.classList.remove("active"));

        // إظهار التبويب الحالي وتفعيل الزر
        document.getElementById(tabName).classList.add("active");
        evt.currentTarget.classList.add("active");
        
        // حفظ التبويب النشط في localStorage
        localStorage.setItem("active_admin_tab", tabName);
    }

    // استعادة التبويب النشط من localStorage عند التحميل
    document.addEventListener("DOMContentLoaded", () => {
        const savedTab = localStorage.getItem("active_admin_tab");
        if (savedTab) {
            const btn = Array.from(document.querySelectorAll(".tab-btn")).find(b => b.getAttribute("onclick").includes(savedTab));
            if (btn) {
                btn.click();
            }
        }
    });

    // Global state for project images upload & cover selection
    let selectedFiles = []; // files selected from the input
    let existingImages = []; // existing images loaded for edit: {path: '...', isCover: true/false}
    let deletedPaths = []; // paths of existing images that the user wants to delete
    let isEditing = false; // flag to know if we are editing

    // Render previews grid (both existing and newly selected images)
    function renderPreviews() {
        const grid = document.getElementById('project-images-preview-grid');
        if (!grid) return;
        grid.innerHTML = '';

        // 1. Render existing images (if editing)
        existingImages.forEach(img => {
            // Skip if marked as deleted
            if (deletedPaths.includes(img.path)) return;

            const card = document.createElement('div');
            card.className = 'preview-card' + (img.isCover ? ' is-cover' : '');
            
            card.innerHTML = `
                <img src="<?php echo e(asset('')); ?>${img.path}" alt="Preview">
                <span class="preview-badge">${img.isCover ? 'الغلاف الحالي' : 'اختر كغلاف'}</span>
                <button type="button" class="preview-delete-btn" onclick="deleteExistingPath(event, '${img.path}')"><i class="fa-solid fa-times"></i></button>
            `;

            card.addEventListener('click', () => {
                setExistingCover(img.path);
            });

            grid.appendChild(card);
        });

        // 2. Render newly selected files
        selectedFiles.forEach((file, index) => {
            const card = document.createElement('div');
            const isCover = (document.getElementById('cover_source').value === 'new' && parseInt(document.getElementById('cover_val').value) === index);
            card.className = 'preview-card' + (isCover ? ' is-cover' : '');

            // Use FileReader to display local preview
            const reader = new FileReader();
            reader.onload = function(e) {
                card.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <span class="preview-badge">${isCover ? 'غلاف جديد' : 'اختر كغلاف'}</span>
                    <button type="button" class="preview-delete-btn" onclick="deleteNewFile(event, ${index})"><i class="fa-solid fa-times"></i></button>
                `;
            };
            reader.readAsDataURL(file);

            card.addEventListener('click', () => {
                setNewCover(index);
            });

            grid.appendChild(card);
        });

        // If grid is empty
        if (grid.children.length === 0) {
            grid.innerHTML = '<div style="grid-column: 1/-1; color: var(--muted); text-align: center; line-height: 80px;">لا توجد صور محددة حالياً.</div>';
        }
    }

    // Handlers for managing cover selection and deletions
    function deleteExistingPath(e, path) {
        e.stopPropagation();
        deletedPaths.push(path);
        
        // Remove old inputs from container
        updateDeletedInputs();

        // If the deleted image was the cover, we must select another cover
        const coverSource = document.getElementById('cover_source').value;
        const coverVal = document.getElementById('cover_val').value;
        if (coverSource === 'existing' && coverVal === path) {
            const nextActive = existingImages.find(img => !deletedPaths.includes(img.path));
            if (nextActive) {
                setExistingCover(nextActive.path);
            } else if (selectedFiles.length > 0) {
                setNewCover(0);
            } else {
                document.getElementById('cover_source').value = 'existing';
                document.getElementById('cover_val').value = '';
            }
        }
        renderPreviews();
    }

    function updateDeletedInputs() {
        const container = document.getElementById('deleted-paths-inputs');
        if (!container) return;
        container.innerHTML = '';
        deletedPaths.forEach(path => {
            container.innerHTML += `<input type="hidden" name="deleted_paths[]" value="${path}">`;
        });
    }

    function deleteNewFile(e, index) {
        e.stopPropagation();
        selectedFiles.splice(index, 1);
        
        // If the deleted file was the cover, reset cover
        const coverSource = document.getElementById('cover_source').value;
        const coverVal = parseInt(document.getElementById('cover_val').value);
        if (coverSource === 'new' && coverVal === index) {
            if (selectedFiles.length > 0) {
                setNewCover(0);
            } else {
                const nextActive = existingImages.find(img => !deletedPaths.includes(img.path));
                if (nextActive) {
                    setExistingCover(nextActive.path);
                } else {
                    document.getElementById('cover_source').value = 'new';
                    document.getElementById('cover_val').value = '0';
                    document.getElementById('cover_index').value = '0';
                }
            }
        } else if (coverSource === 'new' && coverVal > index) {
            const newVal = coverVal - 1;
            document.getElementById('cover_val').value = newVal;
            document.getElementById('cover_index').value = newVal;
        }
        
        renderPreviews();
    }

    function setExistingCover(path) {
        document.getElementById('cover_source').value = 'existing';
        document.getElementById('cover_val').value = path;
        document.getElementById('cover_index').value = '0';
        
        existingImages.forEach(img => {
            img.isCover = (img.path === path);
        });
        renderPreviews();
    }

    function setNewCover(index) {
        document.getElementById('cover_source').value = 'new';
        document.getElementById('cover_val').value = index;
        document.getElementById('cover_index').value = index;
        
        existingImages.forEach(img => {
            img.isCover = false;
        });
        renderPreviews();
    }

    // Setup file input listener on DOM load
    document.addEventListener("DOMContentLoaded", () => {
        const fileInput = document.getElementById('project_images_input');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                const files = Array.from(e.target.files);
                selectedFiles = selectedFiles.concat(files);
                
                // If there was no cover selected yet, select the first newly added image as cover
                const coverSource = document.getElementById('cover_source').value;
                const coverVal = document.getElementById('cover_val').value;
                const activeExisting = existingImages.find(img => !deletedPaths.includes(img.path) && img.isCover);
                if (!activeExisting && selectedFiles.length > 0 && coverSource === 'new' && coverVal === '0') {
                    setNewCover(0);
                }
                
                renderPreviews();
            });
        }

        // Intercept form submit and use AJAX with progress bar
        const projectForm = document.getElementById('project-main-form');
        if (projectForm) {
            projectForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validation
                const coverSource = document.getElementById('cover_source').value;
                const coverVal = document.getElementById('cover_val').value;
                const activeExistingCount = existingImages.filter(img => !deletedPaths.includes(img.path)).length;
                
                if (coverSource === 'new' && selectedFiles.length === 0 && activeExistingCount === 0) {
                    alert('يرجى اختيار صورة واحدة على الأقل للعمل.');
                    return;
                }
                if (coverSource === 'existing' && !coverVal) {
                    alert('يرجى اختيار صورة الغلاف للعمل.');
                    return;
                }

                // Prepare FormData
                const formData = new FormData();
                formData.append('_token', projectForm.querySelector('input[name="_token"]').value);
                formData.append('title', document.getElementById('project_title').value);
                formData.append('category', document.getElementById('project_category').value);
                formData.append('description', document.getElementById('project_description').value);
                formData.append('cover_source', coverSource);
                formData.append('cover_val', coverVal);
                formData.append('cover_index', document.getElementById('cover_index').value);
                
                deletedPaths.forEach(path => {
                    formData.append('deleted_paths[]', path);
                });
                selectedFiles.forEach(file => {
                    formData.append('images[]', file);
                });

                // Show progress bar
                document.getElementById('upload-progress-container').style.display = 'block';
                const submitBtn = document.getElementById('submit-project-btn');
                submitBtn.disabled = true;

                const xhr = new XMLHttpRequest();
                xhr.open('POST', projectForm.action, true);
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

                let startTime = Date.now();

                xhr.upload.addEventListener('progress', function(evt) {
                    if (evt.lengthComputable) {
                        const percent = Math.round((evt.loaded / evt.total) * 100);
                        
                        // Update progress bar width and percentage text
                        document.getElementById('upload-progress-bar').style.width = percent + '%';
                        document.getElementById('upload-percentage-text').innerText = percent + '%';

                        // Bytes detail
                        const loadedMB = (evt.loaded / (1024 * 1024)).toFixed(2);
                        const totalMB = (evt.total / (1024 * 1024)).toFixed(2);
                        document.getElementById('upload-bytes-text').innerText = `${loadedMB} MB من ${totalMB} MB`;

                        // Speed and remaining time calculation
                        const elapsedTime = (Date.now() - startTime) / 1000; // in seconds
                        const uploadSpeed = evt.loaded / elapsedTime; // bytes per second
                        const remainingBytes = evt.total - evt.loaded;
                        
                        let remainingTimeText = 'جاري الحساب...';
                        if (uploadSpeed > 0) {
                            const remainingSeconds = Math.round(remainingBytes / uploadSpeed);
                            if (remainingSeconds < 60) {
                                remainingTimeText = `المتبقي: ${remainingSeconds} ثانية`;
                            } else {
                                remainingTimeText = `المتبقي: ${Math.floor(remainingSeconds / 60)} دقيقة و ${remainingSeconds % 60} ثانية`;
                            }
                        }
                        document.getElementById('upload-time-text').innerText = remainingTimeText;
                    }
                });

                xhr.onload = function() {
                    submitBtn.disabled = false;
                    if (xhr.status >= 200 && xhr.status < 300) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            document.getElementById('upload-status-text').innerText = 'تم الرفع والحفظ بنجاح!';
                            // Alert and reload
                            alert(response.message);
                            window.location.reload();
                        } else {
                            alert('حدث خطأ أثناء حفظ العمل.');
                            resetProgress();
                        }
                    } else if (xhr.status === 422) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            let errorMsg = 'فشل التحقق من البيانات:\n';
                            if (response.errors) {
                                for (const key in response.errors) {
                                    errorMsg += `- ${response.errors[key].join(', ')}\n`;
                                }
                            } else {
                                errorMsg += response.message || 'بيانات غير صالحة.';
                            }
                            alert(errorMsg);
                        } catch(e) {
                            alert('حدث خطأ في التحقق من البيانات المرسلة.');
                        }
                        resetProgress();
                    } else {
                        alert(`فشل الرفع (رمز الخطأ: ${xhr.status}). يرجى التأكد من أن الملفات صور صالحة وحجمها مناسب.`);
                        resetProgress();
                    }
                };

                xhr.onerror = function() {
                    submitBtn.disabled = false;
                    alert('حدث خطأ في الاتصال بالشبكة.');
                    resetProgress();
                };

                xhr.send(formData);
            });
        }
    });

    // Edit Project UI populator
    function editProject(id, title, category, description, actionUrl, thumbnail, imagesBase64) {
        isEditing = true;
        document.getElementById("project-form-title").innerText = "تعديل العمل: " + title;
        document.getElementById("project-main-form").action = actionUrl;
        document.getElementById("cancel-project-edit").style.display = "inline-flex";

        document.getElementById("project_title").value = title;
        document.getElementById("project_category").value = category;
        document.getElementById("project_description").value = description;
        
        // Reset states
        selectedFiles = [];
        existingImages = [];
        deletedPaths = [];
        updateDeletedInputs();
        
        // Decode and parse gallery images from base64
        let images = [];
        try {
            images = JSON.parse(atob(imagesBase64));
        } catch(e) {
            console.error("Failed to parse gallery images", e);
        }

        // Set existing cover
        if (thumbnail) {
            existingImages.push({ path: thumbnail, isCover: true });
            document.getElementById('cover_source').value = 'existing';
            document.getElementById('cover_val').value = thumbnail;
            document.getElementById('cover_index').value = '0';
        }

        // Add other gallery images
        images.forEach(img => {
            existingImages.push({ path: img.image_path, isCover: false });
        });

        // Reset file input
        document.getElementById('project_images_input').value = '';

        resetProgress();
        renderPreviews();

        document.getElementById("project-form-container").scrollIntoView({ behavior: "smooth" });
    }

    function resetProjectForm() {
        isEditing = false;
        document.getElementById("project-form-title").innerText = "إضافة عمل جديد";
        document.getElementById("project-main-form").action = "<?php echo e(route('admin.projects.store')); ?>";
        document.getElementById("project-main-form").reset();
        
        selectedFiles = [];
        existingImages = [];
        deletedPaths = [];
        updateDeletedInputs();
        
        document.getElementById('cover_source').value = 'new';
        document.getElementById('cover_val').value = '0';
        document.getElementById('cover_index').value = '0';
        document.getElementById('project_images_input').value = '';
        
        document.getElementById('cancel-project-edit').style.display = "none";
        
        resetProgress();
        renderPreviews();
    }

    function resetProgress() {
        document.getElementById('upload-progress-container').style.display = 'none';
        document.getElementById('upload-progress-bar').style.width = '0%';
        document.getElementById('upload-percentage-text').innerText = '0%';
        document.getElementById('upload-bytes-text').innerText = '0 MB / 0 MB';
        document.getElementById('upload-time-text').innerText = 'الوقت المتبقي: --';
        document.getElementById('upload-status-text').innerText = 'جاري الرفع...';
    }

    // إدارة الصور الإضافية للعمل
    function manageImages(id, title, actionUrl, images) {
        document.getElementById("gallery-form-container").style.display = "block";
        document.getElementById("gallery-project-title").innerText = title;
        document.getElementById("gallery-upload-form").action = actionUrl;

        const grid = document.getElementById("gallery-thumbs-grid");
        grid.innerHTML = "";

        if (images.length === 0) {
            grid.innerHTML = "<p style='grid-column: 1/-1; color: var(--muted);'>لا توجد صور إضافية لهذا العمل حالياً.</p>";
        } else {
            images.forEach(img => {
                const deleteUrl = "<?php echo e(url('/admin/project-images')); ?>/" + img.id;
                grid.innerHTML += `
                    <div class="gallery-thumb-item">
                        <img src="<?php echo e(asset('')); ?>${img.image_path}" alt="Thumb">
                        <form method="POST" action="${deleteUrl}" onsubmit="return confirm('هل تريد حذف هذه الصورة من المعرض؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"><i class="fa-solid fa-times"></i></button>
                        </form>
                    </div>
                `;
            });
        }

        document.getElementById("gallery-form-container").scrollIntoView({ behavior: "smooth" });
    }

    // إدارة الخدمات (تعديل)
    function editOffer(id, title, price, description, icon, actionUrl) {
        document.getElementById("offer-form-title").innerText = "تعديل الخدمة: " + title;
        document.getElementById("offer-main-form").action = actionUrl;
        document.getElementById("cancel-offer-edit").style.display = "inline-flex";

        document.getElementById("offer_title").value = title;
        document.getElementById("offer_price").value = price;
        document.getElementById("offer_icon").value = icon;
        document.getElementById("offer_description").value = description;
    }

    function resetOfferForm() {
        document.getElementById("offer-form-title").innerText = "إضافة خدمة/عرض جديد";
        document.getElementById("offer-main-form").action = "<?php echo e(route('admin.offers.store')); ?>";
        document.getElementById("offer-main-form").reset();
        document.getElementById("cancel-offer-edit").style.display = "none";
    }

    // إضافة صفوف ديناميكية للخبرات
    let expCount = <?php echo e(count($settings['experiences'] ?? [])); ?>;
    function addExperienceRow() {
        expCount++;
        const container = document.getElementById("experiences-rows");
        const rowId = "exp-row-new-" + expCount;
        const html = `
            <div class="dynamic-row" id="${rowId}">
                <input type="text" name="exp_title[]" placeholder="اسم الشركة / نوع الخبرة" required>
                <textarea name="exp_desc[]" rows="2" placeholder="وصف الخبرة والتفاصيل" required></textarea>
                <button type="button" class="btn danger" onclick="removeRow('${rowId}')"><i class="fa-solid fa-times"></i></button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
    }

    // إضافة صفوف ديناميكية للأدوات
    let toolCount = <?php echo e(count($settings['tools'] ?? [])); ?>;
    function addToolRow() {
        toolCount++;
        const container = document.getElementById("tools-rows");
        const rowId = "tool-row-new-" + toolCount;
        const html = `
            <div class="dynamic-row" id="${rowId}">
                <input type="text" name="tool_name[]" placeholder="اسم الأداة (Photoshop)" required>
                <input type="text" name="tool_icon[]" value="fa-solid fa-layer-group" placeholder="كود أيقونة الأداة" required>
                <textarea name="tool_desc[]" rows="2" placeholder="وصف استخدامك للأداة" required></textarea>
                <button type="button" class="btn danger" onclick="removeRow('${rowId}')"><i class="fa-solid fa-times"></i></button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
    }

    function removeRow(id) {
        const row = document.getElementById(id);
        if (row) {
            row.remove();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ammar\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>