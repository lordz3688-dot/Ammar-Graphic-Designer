<?php $__env->startSection('title', 'عمار | السيرة الذاتية'); ?>

<?php $__env->startSection('content'); ?>
<section class="shell page-hero">
    <div class="eyebrow">السيرة الذاتية</div>
    <h1>مصمم جرافيك شغوف بصناعة هوية بصرية تترك أثراً.</h1>
    <p class="lead">
        <?php echo e($settings['about_bio'] ?? 'مرحباً، أنا مصمم جرافيك شغوف، أمتلك خبرة تمتد لأربع سنوات في تحويل الأفكار والرؤى إلى واقع بصري ملموس. على مدار مسيرتي المهنية، ركزت على تقديم تصاميم تجمع بين الجمالية البصرية والوظيفة العملية التي تخدم أهداف العمل.'); ?>

    </p>
</section>

<section class="shell section resume-grid">
    <aside class="section-panel">
        <h2>ملخص مهني</h2>
        <p class="lead">
            <?php echo e($settings['about_summary'] ?? 'أؤمن أن التصميم ليس مجرد ألوان وأشكال، بل هو لغة لحل المشكلات وإيصال الرسائل. يسعدني دائماً التعاون مع شركاء نجاح جدد لترك بصمة بصرية مميزة.'); ?>

        </p>
        <ul class="contact-list">
            <li><i class="fa-brands fa-behance"></i><a href="<?php echo e($settings['behance_url'] ?? 'https://www.behance.net/ammarsalim4'); ?>" target="_blank">Behance Portfolio</a></li>
            <li><i class="fa-brands fa-x-twitter"></i><a href="<?php echo e($settings['twitter_url'] ?? 'https://x.com/LordZer53859986'); ?>" target="_blank">X / Twitter</a></li>
            <li><i class="fa-brands fa-whatsapp"></i><a href="<?php echo e($settings['whatsapp_url'] ?? 'https://wa.me/967770561991'); ?>" target="_blank">WhatsApp</a></li>
        </ul>
    </aside>

    <div class="section-panel">
        <h2>الخبرة والمهارات</h2>
        <div class="timeline">
            <?php $__empty_1 = true; $__currentLoopData = $settings['experiences'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="timeline-item">
                    <h3><?php echo e($exp['title']); ?></h3>
                    <p><?php echo e($exp['desc']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="timeline-item">
                    <h3>خبرة تصميم تمتد لأربع سنوات</h3>
                    <p>تحويل الأفكار والرؤى إلى حلول بصرية قابلة للاستخدام في التسويق، الهوية، المحتوى الرقمي، والمطبوعات.</p>
                </div>
                <div class="timeline-item">
                    <h3>منهجية عمل احترافية</h3>
                    <p>فهم الهدف أولاً، بناء اتجاه بصري واضح، ثم تنفيذ تصميم متوازن يخدم الرسالة ويعزز حضور العلامة.</p>
                </div>
            <?php endif; ?>
        </div>

        <h2 style="margin-top: 32px;">أدوات التصميم</h2>
        <ul class="tool-list">
            <?php $__empty_1 = true; $__currentLoopData = $settings['tools'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <i class="<?php echo e($tool['icon'] ?? 'fa-solid fa-layer-group'); ?>"></i>
                    <span><strong><?php echo e($tool['name']); ?>:</strong> <?php echo e($tool['desc']); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li><i class="fa-solid fa-layer-group"></i><span><strong>Adobe Photoshop:</strong> لدمج الصور، التعديل المتقدم، وخلق المؤثرات البصرية الساحرة.</span></li>
                <li><i class="fa-solid fa-vector-square"></i><span><strong>Adobe Illustrator:</strong> لبناء الهويات البصرية، الشعارات، والرسومات المتجهية بدقة متناهية.</span></li>
                <li><i class="fa-solid fa-book"></i><span><strong>Adobe InDesign:</strong> لتنسيق المطبوعات، الكتب الرقمية، والمجلات بهندسة بصرية مريحة للقارئ.</span></li>
            <?php endif; ?>
        </ul>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ammar\resources\views/resume.blade.php ENDPATH**/ ?>