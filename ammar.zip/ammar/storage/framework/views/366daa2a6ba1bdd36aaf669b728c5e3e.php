<?php $__env->startSection('title', 'عمار | تواصل'); ?>

<?php $__env->startSection('content'); ?>
<section class="shell page-hero">
    <div class="eyebrow">ابدأ مشروعك</div>
    <h1>لنتعاون على تصميم يليق بفكرتك.</h1>
    <p class="lead">اختر وسيلة التواصل المناسبة، وسأكون سعيداً بمناقشة مشروعك وتحويله إلى نتيجة بصرية محترفة.</p>
    <div class="social-row">
        <a class="btn btn-primary" href="<?php echo e($settings['whatsapp_url'] ?? 'https://wa.me/967770561991'); ?>" target="_blank"><i class="fa-brands fa-whatsapp"></i> واتساب</a>
        <a class="btn btn-ghost" href="<?php echo e($settings['behance_url'] ?? 'https://www.behance.net/ammarsalim4'); ?>" target="_blank"><i class="fa-brands fa-behance"></i> بيهانس</a>
        <a class="btn btn-ghost" href="<?php echo e($settings['twitter_url'] ?? 'https://x.com/LordZer53859986'); ?>" target="_blank"><i class="fa-brands fa-x-twitter"></i> منصة X</a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ammar\resources\views/contact.blade.php ENDPATH**/ ?>