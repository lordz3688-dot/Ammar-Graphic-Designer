<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'عمار | مصمم جرافيك')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --bg: #090314;
            --surface: rgba(19, 13, 34, 0.62);
            --surface-2: rgba(30, 21, 51, 0.88);
            --ink: #ffffff;
            --text: #e0dcf0;
            --muted: #a39bb8;
            --line: rgba(255, 255, 255, 0.08);
            --accent: #ff6b35; /* Orange/Coral brand color */
            --gold: #ffd166;   /* Gold/Yellow color */
            --green: #22baa1;  /* Teal color */
            --blue: #4fa5ff;   /* Neon light blue */
            --shadow: 0 24px 70px rgba(0, 0, 0, 0.65);
        }

        * { box-sizing: border-box; }

        @font-face {
            font-family: 'Thmanyah';
            src: url('https://framerusercontent.com/assets/Ej0k3h4Mi5O7TSo2w2JaDCPRgvo.woff2') format('woff2');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Thmanyah';
            src: url('https://framerusercontent.com/assets/3XGelYpTgxSxBXN4Oieg9Dt3bc.woff2') format('woff2');
            font-weight: 500;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Thmanyah';
            src: url('https://framerusercontent.com/assets/JUv6rms2ye2kYL3UI3O9YyExQcQ.woff2') format('woff2');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Thmanyah';
            src: url('https://framerusercontent.com/assets/2MgF2LENj0ar3gdEjyf3HoLd6iw.woff2') format('woff2');
            font-weight: 300;
            font-style: normal;
            font-display: swap;
        }

        body {
            margin: 0;
            font-family: "Thmanyah", "Tajawal", "Segoe UI", sans-serif;
            background:
                radial-gradient(circle at top right, rgba(255, 107, 53, 0.14), transparent 45rem),
                radial-gradient(circle at bottom left, rgba(140, 69, 255, 0.12), transparent 40rem),
                radial-gradient(circle at 50% 50%, rgba(34, 186, 161, 0.06), transparent 50rem),
                linear-gradient(180deg, #090314 0%, #0d091a 100%),
                var(--bg);
            color: var(--text);
            min-height: 100vh;
            overflow-x: hidden;
            cursor: none; /* Hide default cursor */
        }

        a { color: inherit; text-decoration: none; cursor: none; }
        img { max-width: 100%; display: block; }
        button, input, textarea, select { cursor: none; }

        .shell {
            width: min(1160px, calc(100% - 40px));
            margin: 0 auto;
        }

        .navbar {
            position: sticky;
            top: 0;
            z-index: 20;
            background: rgba(9, 3, 20, 0.75);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.07);
        }

        .nav-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            min-height: 76px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 900;
            font-size: 1.2rem;
            color: #fff;
        }

        .brand-mark {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, var(--accent), var(--gold));
            color: #090314;
            font-weight: 900;
            box-shadow: 0 8px 24px rgba(255, 107, 53, 0.3);
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .nav-links a {
            color: var(--muted);
            font-weight: 700;
            padding: 10px 14px;
            border-radius: 8px;
            transition: .2s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #fff;
            background: rgba(255, 107, 53, 0.12);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border: 1px solid transparent;
            border-radius: 8px;
            padding: 13px 18px;
            font-weight: 800;
            transition: .2s ease;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
            box-shadow: 0 14px 32px rgba(255, 107, 53, 0.25);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            background: #ff7d4d;
            box-shadow: 0 16px 36px rgba(255, 107, 53, 0.35);
        }

        .btn-ghost {
            border-color: var(--line);
            color: var(--text);
            background: rgba(255, 255, 255, .03);
        }

        .btn-ghost:hover {
            border-color: var(--accent);
            color: white;
            background: rgba(255, 107, 53, 0.1);
        }

        .hero {
            min-height: calc(100vh - 76px);
            display: grid;
            grid-template-columns: minmax(0, 1.12fr) minmax(280px, .88fr);
            align-items: center;
            gap: clamp(30px, 5vw, 70px);
            padding: clamp(44px, 6vw, 82px) 0 50px;
        }

        .eyebrow {
            color: var(--gold);
            font-weight: 800;
            margin-bottom: 14px;
            letter-spacing: 0.5px;
        }

        h1, h2, h3, p { margin-top: 0; }

        h1 {
            font-size: clamp(2.6rem, 5.7vw, 5.25rem);
            line-height: 1.18;
            margin-bottom: 24px;
            letter-spacing: 0;
            max-width: 860px;
            color: #fff;
        }

        h2 {
            line-height: 1.26;
            letter-spacing: 0;
            color: #fff;
        }

        h3 {
            line-height: 1.45;
            letter-spacing: 0;
            color: #fff;
        }

        .gradient-text {
            background: linear-gradient(135deg, var(--accent), var(--gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            color: transparent;
        }

        .lead {
            color: var(--muted);
            font-size: 1.18rem;
            line-height: 2;
            max-width: 690px;
        }

        .hero-actions, .social-row {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 26px;
        }

        .portrait-wrap {
            position: relative;
        }

        .portrait-wrap::before {
            content: '';
            position: absolute;
            top: -20px;
            left: -20px;
            right: 20px;
            bottom: 20px;
            border: 2px solid var(--accent);
            border-radius: 12px;
            z-index: 1;
            pointer-events: none;
            opacity: 0.3;
        }

        .portrait {
            aspect-ratio: 4 / 5;
            border-radius: 12px;
            object-fit: cover;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: var(--shadow);
            position: relative;
            z-index: 2;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 14px;
            margin-top: 34px;
        }

        .stat, .card, .section-panel, .work-card {
            background: var(--surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--line);
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .stat { padding: 18px; }
        .stat strong { display: block; font-size: 1.6rem; color: var(--gold); }
        .stat span { color: var(--muted); font-weight: 700; }

        .section {
            padding: clamp(54px, 7vw, 86px) 0;
        }

        .section-head {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: 12px;
            margin-bottom: 36px;
        }

        .section-head h2 {
            font-size: clamp(2rem, 3.8vw, 3.25rem);
            margin-bottom: 0;
        }

        .section-head p {
            color: var(--muted);
            line-height: 1.8;
            max-width: 560px;
            margin-bottom: 0;
        }

        .grid-3 {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 20px;
        }

        .card {
            padding: 24px;
            min-height: 180px;
            transition: transform 0.3s ease, border-color 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            border-color: rgba(255, 107, 53, 0.4);
        }

        .card i {
            color: var(--accent);
            font-size: 1.6rem;
            margin-bottom: 18px;
        }

        .card h3 { margin-bottom: 10px; font-size: 1.25rem; }
        .card p { color: var(--muted); line-height: 1.8; margin-bottom: 0; }

        .page-hero {
            padding: clamp(56px, 8vw, 92px) 0 40px;
            text-align: center;
        }

        .page-hero .lead {
            margin-inline: auto;
        }

        .page-hero h1 {
            font-size: clamp(2.35rem, 4.8vw, 4.4rem);
            line-height: 1.22;
            margin-inline: auto;
        }

        .resume-grid {
            display: grid;
            grid-template-columns: .8fr 1.2fr;
            gap: 24px;
            align-items: start;
        }

        .section-panel { padding: clamp(22px, 3vw, 34px); }

        .section-panel h2 {
            margin-bottom: 18px;
            border-bottom: 1px solid var(--line);
            padding-bottom: 10px;
            text-align: center;
        }

        .timeline {
            display: grid;
            gap: 14px;
        }

        .timeline-item {
            padding: 20px;
            background: rgba(255, 255, 255, .02);
            border: 1px solid var(--line);
            border-radius: 8px;
            border-right: 3px solid var(--accent);
        }

        .timeline-item h3 {
            margin-bottom: 8px;
        }

        .tool-list, .contact-list {
            display: grid;
            gap: 12px;
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .tool-list li, .contact-list li {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            padding: 16px;
            background: rgba(255, 255, 255, .02);
            border: 1px solid var(--line);
            border-radius: 8px;
            color: var(--text);
            line-height: 1.7;
        }

        .tool-list i, .contact-list i { color: var(--gold); margin-top: 4px; }

        .works-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 18px;
        }

        .work-card {
            overflow: hidden;
            transition: .2s ease;
        }

        .work-card:hover { transform: translateY(-4px); border-color: rgba(255, 107, 53, .55); }
        .work-card img { width: 100%; aspect-ratio: 1 / 1; object-fit: cover; }
        .work-card div { padding: 16px; }
        .work-card h3 { font-size: 1.05rem; margin-bottom: 6px; }
        .work-card p { color: var(--muted); margin-bottom: 0; line-height: 1.75; }

        .footer {
            border-top: 1px solid var(--line);
            padding: 28px 0;
            color: var(--muted);
            background: rgba(9, 3, 20, 0.4);
        }

        /* Custom Cursor Styling */
        .cursor {
            width: 22px;
            height: 22px;
            border: 2px solid var(--accent);
            border-radius: 50%;
            position: fixed;
            pointer-events: none;
            z-index: 9999;
            transition: width 0.3s ease, height 0.3s ease, border-color 0.3s ease, background 0.3s ease;
            transform: translate(-50%, -50%);
            mix-blend-mode: screen;
        }

        .cursor-dot {
            width: 6px;
            height: 6px;
            background: var(--accent);
            border-radius: 50%;
            position: fixed;
            pointer-events: none;
            z-index: 9999;
            transform: translate(-50%, -50%);
            transition: width 0.2s ease, height 0.2s ease, background 0.3s ease;
        }

        .cursor.hover {
            width: 55px;
            height: 55px;
            border-color: var(--gold);
            background: rgba(255, 107, 53, 0.08);
        }

        .cursor-dot.hover {
            width: 10px;
            height: 10px;
            background: var(--gold);
        }

        @media (pointer: coarse) {
            .cursor, .cursor-dot { display: none; }
            body { cursor: auto; }
        }

        @media (min-width: 821px) and (max-width: 1100px) {
            .shell { width: min(960px, calc(100% - 44px)); }
            .hero {
                grid-template-columns: minmax(0, 1fr) 330px;
                min-height: auto;
            }
            h1 { font-size: clamp(3rem, 5.8vw, 4.4rem); }
            .grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .resume-grid { grid-template-columns: 1fr 1.35fr; }
        }

        @media (max-width: 820px) {
            .shell { width: min(100% - 30px, 720px); }
            .nav-inner {
                align-items: center;
                flex-direction: column;
                padding: 14px 0 12px;
                gap: 14px;
            }
            .brand {
                width: 100%;
                justify-content: center;
                text-align: center;
            }
            .nav-links {
                width: 100%;
                justify-content: center;
                flex-wrap: wrap;
                gap: 8px;
            }
            .nav-links a {
                padding: 9px 12px;
                font-size: .98rem;
            }
            .hero, .resume-grid { grid-template-columns: 1fr; }
            .hero {
                min-height: auto;
                text-align: center;
                padding-top: 42px;
            }
            .hero .lead, .page-hero .lead {
                margin-left: auto;
                margin-right: auto;
            }
            .hero-actions, .social-row {
                justify-content: center;
            }
            .portrait-wrap {
                max-width: 420px;
                margin: 0 auto;
            }
            .stats { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .grid-3 { grid-template-columns: 1fr; }
            .section-head {
                align-items: center;
                text-align: center;
                flex-direction: column;
            }
            .page-hero {
                text-align: center;
            }
        }

        @media (max-width: 560px) {
            .shell { width: min(100% - 24px, 460px); }
            .brand { font-size: 1.05rem; }
            .brand-mark {
                width: 38px;
                height: 38px;
            }
            .nav-links {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 8px;
            }
            .nav-links a {
                text-align: center;
                white-space: nowrap;
                background: rgba(255, 255, 255, .02);
                border: 1px solid var(--line);
            }
            h1 {
                font-size: clamp(2.2rem, 12vw, 3.25rem);
                line-height: 1.24;
            }
            .page-hero h1 {
                font-size: clamp(2rem, 10.5vw, 2.85rem);
                line-height: 1.28;
            }
            .lead {
                font-size: 1.04rem;
                line-height: 1.95;
            }
            .hero-actions .btn,
            .social-row .btn {
                width: 100%;
            }
            .stats {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            .stat {
                padding: 16px;
            }
            .card {
                padding: 20px;
                min-height: auto;
            }
            .tool-list li, .contact-list li {
                padding: 14px;
            }
            .works-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="cursor"></div>
    <div class="cursor-dot"></div>

    <header class="navbar">
        <div class="shell nav-inner">
            <a class="brand" href="{{ route('home') }}">
                <span class="brand-mark">ع</span>
                <span>عمار | مصمم جرافيك</span>
            </a>
            <nav class="nav-links" aria-label="القائمة الرئيسية">
                <a href="{{ route('home') }}" class="{{ request()->routeIs('home') ? 'active' : '' }}">الرئيسية</a>
                <a href="{{ route('works') }}" class="{{ request()->routeIs('works') ? 'active' : '' }}">الأعمال</a>
                <a href="{{ route('resume') }}" class="{{ request()->routeIs('resume') ? 'active' : '' }}">السيرة الذاتية</a>
                <a href="{{ route('contact') }}" class="{{ request()->routeIs('contact') ? 'active' : '' }}">تواصل</a>
                @if(session('admin_id'))
                    <a href="{{ route('admin.dashboard') }}" style="color: var(--gold);" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"><i class="fa-solid fa-gauge"></i> لوحة التحكم</a>
                @endif
            </nav>
        </div>
    </header>

    <main>
        @yield('content')
    </main>

    <footer class="footer">
        <div class="shell">
            <p>© {{ date('Y') }} عمار. جميع الحقوق محفوظة.</p>
        </div>
    </footer>

    <script>
        const cursor = document.querySelector('.cursor');
        const cursorDot = document.querySelector('.cursor-dot');
        document.addEventListener('mousemove', (e) => {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';
            cursorDot.style.left = e.clientX + 'px';
            cursorDot.style.top = e.clientY + 'px';
        });
        
        const attachHover = () => {
            const hoverElements = document.querySelectorAll('a, button, .thumb-btn, input, textarea, select, [data-hover], .admin-actions button, form button');
            hoverElements.forEach(el => {
                el.addEventListener('mouseenter', () => {
                    cursor.classList.add('hover');
                    cursorDot.classList.add('hover');
                });
                el.addEventListener('mouseleave', () => {
                    cursor.classList.remove('hover');
                    cursorDot.classList.remove('hover');
                });
            });
        };
        attachHover();
        
        const observer = new MutationObserver(attachHover);
        observer.observe(document.body, { childList: true, subtree: true });

        document.addEventListener('mouseleave', () => {
            cursor.style.opacity = '0';
            cursorDot.style.opacity = '0';
        });
        document.addEventListener('mouseenter', () => {
            cursor.style.opacity = '1';
            cursorDot.style.opacity = '1';
        });
    </script>
</body>
</html>
