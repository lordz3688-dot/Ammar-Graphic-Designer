@extends('layouts.app')

@section('title', 'عمار | الأعمال')

@section('content')
<section class="shell page-hero works-hero">
    <div class="eyebrow">معرض الأعمال</div>
    <h1>تصاميم مختارة تُظهر الفكرة قبل الزخرفة.</h1>
    <p class="lead">اضغط على أي عمل لعرض كل الصور المرتبطة به، والتنقل بينها، وترك تقييمك وتعليقك.</p>
</section>

@forelse($projects as $category => $items)
    <section class="shell section">
        <div class="section-head">
            <h2>{{ $category ?: 'أعمال متنوعة' }}</h2>
            <p>مجموعة أعمال من هذا التصنيف، مرتبة كبطاقات عرض واضحة وسهلة التصفح.</p>
        </div>
        <div class="course-grid">
            @foreach($items as $project)
                <a class="course-card" href="{{ route('works.show', $project) }}">
                    <span class="course-badge">{{ $project->images->count() + 1 }} صورة</span>
                    <img src="{{ asset($project->thumbnail) }}" alt="{{ $project->title }}">
                    <div class="course-body">
                        <small>{{ $project->category ?: 'تصميم جرافيك' }}</small>
                        <h3>{{ $project->title }}</h3>
                        <p>{{ $project->description ?: 'عمل بصري احترافي ضمن معرض عمار.' }}</p>
                        <span class="course-link"><i class="fa-solid fa-arrow-left"></i> عرض العمل</span>
                    </div>
                </a>
            @endforeach
        </div>
    </section>
@empty
    <section class="shell section" style="text-align: center; padding: 80px 20px; background: var(--surface); border: 1px solid var(--line); border-radius: 14px; box-shadow: var(--shadow);">
        <div style="font-size: 4rem; color: var(--gold); margin-bottom: 24px; text-shadow: 0 0 20px rgba(255, 209, 102, 0.2);"><i class="fa-solid fa-folder-open"></i></div>
        <h2 style="margin-bottom: 12px;">لا توجد أعمال مضافة حالياً</h2>
        <p class="lead" style="color: var(--muted); max-width: 500px; margin: 0 auto; line-height: 1.8;">سيتم إضافة مشاريع وأعمال جديدة قريباً. يرجى زيارة المعرض في وقت لاحق للاطلاع على التحديثات.</p>
    </section>
@endforelse

<style>
    .works-hero {
        text-align: center;
    }

    .works-hero .lead {
        margin-inline: auto;
    }

    .course-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 22px;
    }

    .course-card {
        position: relative;
        display: block;
        overflow: hidden;
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        box-shadow: var(--shadow);
        transition: transform .25s ease, border-color .25s ease;
    }

    .course-card:hover {
        transform: translateY(-7px);
        border-color: rgba(255, 107, 53, .45);
    }

    .course-card img {
        width: 100%;
        aspect-ratio: 16 / 11;
        object-fit: cover;
    }

    .course-badge {
        position: absolute;
        top: 14px;
        right: 14px;
        z-index: 2;
        background: var(--accent);
        color: white;
        border-radius: 999px;
        padding: 7px 12px;
        font-weight: 800;
        box-shadow: 0 12px 24px rgba(232, 100, 47, .26);
    }

    .course-body {
        padding: 22px;
    }

    .course-body small {
        color: var(--gold);
        font-weight: 900;
    }

    .course-body h3 {
        font-size: 1.35rem;
        margin: 10px 0 8px;
    }

    .course-body p {
        color: var(--muted);
        line-height: 1.85;
        margin-bottom: 18px;
    }

    .course-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--accent);
        font-weight: 900;
    }
</style>
@endsection
