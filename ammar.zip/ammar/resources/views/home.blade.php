@extends('layouts.app')

@section('title', 'عمار | مصمم جرافيك')

@section('content')
<section class="shell hero">
    <div>
        <div class="eyebrow">{{ $settings['hero_eyebrow'] ?? 'مصمم جرافيك بخبرة 4 سنوات' }}</div>
        <h1>{!! $settings['hero_title'] ?? 'أحوّل الأفكار إلى <span class="gradient-text">تجارب بصرية</span> واضحة ومؤثرة.' !!}</h1>
        <p class="lead">
            {{ $settings['hero_description'] ?? 'أصمم هويات بصرية، مواد تسويقية، ومنشورات رقمية تجمع بين الجمال والهدف العملي. أتعامل مع كل مشروع كرسالة تحتاج إلى شكل ذكي وصوت بصري مميز.' }}
        </p>
        <div class="hero-actions">
            <a class="btn btn-primary" href="{{ route('works') }}"><i class="fa-solid fa-images"></i> مشاهدة الأعمال</a>
            <a class="btn btn-ghost" href="{{ route('resume') }}"><i class="fa-solid fa-file-lines"></i> السيرة الذاتية</a>
        </div>
        <div class="stats">
            <div class="stat"><strong>{{ $settings['experience_years'] ?? '4+' }}</strong><span>سنوات خبرة</span></div>
            <div class="stat"><strong>{{ $settings['adobe_tools'] ?? '3' }}</strong><span>أدوات Adobe رئيسية</span></div>
            <div class="stat"><strong>{{ $settings['accent_text'] ?? '100%' }}</strong><span>اهتمام بالتفاصيل</span></div>
        </div>
    </div>
    <div class="portrait-wrap">
        <img class="portrait" src="{{ asset($settings['my_photo'] ?? 'photo/myphoto.png') }}" alt="صورة عمار">
    </div>
</section>

<section class="shell section">
    <div class="section-head">
        <h2>خدمات التصميم</h2>
        <p>حلول بصرية للشركات والأفراد، من بناء الهوية وحتى تجهيز المواد الرقمية والمطبوعة.</p>
    </div>
    <div class="grid-3">
        @forelse($offers as $offer)
            <article class="card">
                <i class="{{ $offer->icon ?: 'fa-solid fa-wand-magic-sparkles' }}"></i>
                <h3>{{ $offer->title }}</h3>
                <p>{{ $offer->description }}</p>
            </article>
        @empty
            <article class="card"><i class="fa-solid fa-pen-nib"></i><h3>تصميم الهوية البصرية</h3><p>شعارات، ألوان، خطوط، وتطبيقات تعكس شخصية المشروع بوضوح.</p></article>
            <article class="card"><i class="fa-solid fa-hashtag"></i><h3>تصاميم السوشيال ميديا</h3><p>منشورات احترافية للحملات، العروض، والمحتوى اليومي.</p></article>
            <article class="card"><i class="fa-solid fa-book-open"></i><h3>المطبوعات والملفات الرقمية</h3><p>بروفايلات، مجلات، كتالوجات، ومواد تسويقية جاهزة للنشر.</p></article>
        @endforelse
    </div>
</section>

@if(isset($comments) && $comments->count() > 0)
<section class="shell section" style="border-top: 1px solid var(--line); margin-top: 40px; padding-top: 60px;">
    <div class="section-head">
        <h2>آراء العملاء</h2>
        <p>ماذا يقول العملاء والزوار عن جودة الأعمال والتعامل.</p>
    </div>
    <div class="grid-3">
        @foreach($comments as $comment)
            <article class="card" style="min-height: auto;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                    <strong style="font-size: 1.1rem; color: #fff;">{{ $comment->user_name }}</strong>
                    <span style="color: var(--gold); font-size: 0.9rem;">
                        @for($i = 1; $i <= 5; $i++)
                            <i class="fa-{{ $i <= $comment->rating ? 'solid' : 'regular' }} fa-star"></i>
                        @endfor
                    </span>
                </div>
                <p style="color: var(--muted); line-height: 1.8; font-size: 0.95rem;">
                    "{{ $comment->comment }}"
                </p>
                @if($comment->project)
                    <div style="margin-top: 14px; font-size: 0.85rem; color: var(--accent); font-weight: 800;">
                        <i class="fa-solid fa-link"></i> عمل مرتبط: <a href="{{ route('works.show', $comment->project) }}" style="text-decoration: underline; color: inherit;">{{ $comment->project->title }}</a>
                    </div>
                @endif
            </article>
        @endforeach
    </div>
</section>
@endif
@endsection
