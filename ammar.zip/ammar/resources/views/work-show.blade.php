@extends('layouts.app')

@section('title', 'عمار | ' . $project->title)

@section('content')
@php
    $images = collect([$project->thumbnail])->merge($project->images->pluck('image_path'))->filter()->values();
@endphp

<section class="shell page-hero project-hero">
    <div>
        <a class="back-link" href="{{ route('works') }}"><i class="fa-solid fa-arrow-right"></i> العودة للأعمال</a>
        <div class="eyebrow">{{ $project->category ?: 'عمل تصميم' }}</div>
        <h1>{{ $project->title }}</h1>
        <p class="lead">{{ $project->description ?: 'معرض صور لهذا العمل مع إمكانية التقليب والتقييم.' }}</p>
    </div>
</section>

<section class="shell project-detail">
    <div class="gallery-panel">
        <div class="gallery-stage">
            <button class="gallery-btn prev" type="button" aria-label="الصورة السابقة"><i class="fa-solid fa-chevron-right"></i></button>
            <img id="mainProjectImage" src="{{ asset($images->first()) }}" alt="{{ $project->title }}">
            <button class="gallery-btn next" type="button" aria-label="الصورة التالية"><i class="fa-solid fa-chevron-left"></i></button>
        </div>
        <div class="thumb-row">
            @foreach($images as $index => $image)
                <button class="thumb-btn {{ $index === 0 ? 'active' : '' }}" type="button" data-index="{{ $index }}">
                    <img src="{{ asset($image) }}" alt="صورة {{ $index + 1 }}">
                </button>
            @endforeach
        </div>
    </div>

    <aside class="review-panel">
        <h2>أضف تقييمك</h2>
        @if(session('message'))
            <div class="notice">{{ session('message') }}</div>
        @endif
        <form method="POST" action="{{ route('works.comments.store', $project) }}" class="review-form">
            @csrf
            <label for="user_name">الاسم</label>
            <input id="user_name" name="user_name" value="{{ old('user_name') }}" required placeholder="اكتب اسمك">

            <label>التقييم</label>
            <div class="stars-input">
                @for($i = 5; $i >= 1; $i--)
                    <input type="radio" name="rating" id="star{{ $i }}" value="{{ $i }}" {{ old('rating', 5) == $i ? 'checked' : '' }}>
                    <label for="star{{ $i }}"><i class="fa-solid fa-star"></i></label>
                @endfor
            </div>

            <label for="comment">التعليق</label>
            <textarea id="comment" name="comment" rows="5" required placeholder="اكتب رأيك في العمل">{{ old('comment') }}</textarea>

            @if($errors->any())
                <div class="notice error">يرجى تعبئة الحقول بشكل صحيح.</div>
            @endif

            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i> إرسال التقييم</button>
        </form>
    </aside>
</section>

<section class="shell section">
    <div class="section-head">
        <h2>تعليقات الزوار</h2>
        <p>آراء وتقييمات مرتبطة بهذا العمل فقط.</p>
    </div>
    <div class="reviews-grid">
        @forelse($project->comments as $comment)
            <article class="review-card">
                <div class="review-top">
                    <strong>{{ $comment->user_name }}</strong>
                    <span>
                        @for($i = 1; $i <= 5; $i++)
                            <i class="fa-{{ $i <= $comment->rating ? 'solid' : 'regular' }} fa-star"></i>
                        @endfor
                    </span>
                </div>
                <p>{{ $comment->comment }}</p>
            </article>
        @empty
            <article class="review-card">
                <strong>كن أول من يقيّم هذا العمل</strong>
                <p>تعليقك يساعد في تطوير جودة العرض والأعمال القادمة.</p>
            </article>
        @endforelse
    </div>
</section>

<style>
    .project-hero {
        padding-bottom: 18px;
    }

    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 18px;
        color: var(--accent);
        font-weight: 900;
    }

    .project-detail {
        display: grid;
        grid-template-columns: minmax(0, 1.4fr) minmax(320px, .6fr);
        gap: 24px;
        align-items: start;
        padding-bottom: 34px;
    }

    .gallery-panel,
    .review-panel,
    .review-card {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 14px;
        box-shadow: var(--shadow);
    }

    .gallery-panel {
        padding: 16px;
    }

    .gallery-stage {
        position: relative;
        overflow: hidden;
        border-radius: 12px;
        background: rgba(0, 0, 0, 0.35);
        border: 1px solid var(--line);
    }

    .gallery-stage img {
        width: 100%;
        aspect-ratio: 16 / 10;
        object-fit: contain;
    }

    .gallery-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 44px;
        height: 44px;
        border: 0;
        border-radius: 50%;
        background: rgba(34, 31, 28, .78);
        color: white;
        cursor: pointer;
        display: grid;
        place-items: center;
    }

    .gallery-btn.prev { right: 14px; }
    .gallery-btn.next { left: 14px; }

    .thumb-row {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(86px, 1fr));
        gap: 10px;
        margin-top: 12px;
    }

    .thumb-btn {
        border: 2px solid transparent;
        border-radius: 8px;
        padding: 0;
        overflow: hidden;
        cursor: pointer;
        background: transparent;
    }

    .thumb-btn.active {
        border-color: var(--accent);
    }

    .thumb-btn img {
        width: 100%;
        aspect-ratio: 1 / 1;
        object-fit: cover;
    }

    .review-panel {
        padding: 24px;
    }

    .review-form label {
        display: block;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .review-form input,
    .review-form textarea {
        width: 100%;
        border: 1px solid var(--line);
        background: rgba(255, 255, 255, 0.03);
        color: #fff;
        border-radius: 8px;
        padding: 13px 14px;
        margin-bottom: 16px;
        font-family: inherit;
        font-size: 1rem;
    }

    .stars-input {
        display: flex;
        flex-direction: row-reverse;
        justify-content: flex-end;
        gap: 6px;
        margin-bottom: 16px;
    }

    .stars-input input {
        display: none;
    }

    .stars-input label {
        color: #d2c3ad;
        cursor: pointer;
        font-size: 1.45rem;
        margin: 0;
    }

    .stars-input input:checked ~ label,
    .stars-input label:hover,
    .stars-input label:hover ~ label {
        color: var(--gold);
    }

    .notice {
        background: rgba(33, 125, 114, .12);
        color: var(--green);
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 14px;
        font-weight: 800;
    }

    .notice.error {
        background: rgba(232, 100, 47, .12);
        color: var(--accent);
    }

    .reviews-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 16px;
    }

    .review-card {
        padding: 20px;
    }

    .review-top {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: center;
        margin-bottom: 10px;
    }

    .review-top span {
        color: var(--gold);
        white-space: nowrap;
    }

    .review-card p {
        color: var(--muted);
        line-height: 1.85;
        margin-bottom: 0;
    }

    @media (max-width: 900px) {
        .project-detail {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 560px) {
        .gallery-panel,
        .review-panel {
            padding: 12px;
        }

        .gallery-stage img {
            aspect-ratio: 1 / 1;
        }

        .gallery-btn {
            width: 38px;
            height: 38px;
        }
    }
</style>

<script>
    const projectImages = @json($images->map(fn ($image) => asset($image))->values());
    let activeImage = 0;
    const mainImage = document.getElementById('mainProjectImage');
    const thumbs = document.querySelectorAll('.thumb-btn');

    function setImage(index) {
        activeImage = (index + projectImages.length) % projectImages.length;
        mainImage.src = projectImages[activeImage];
        thumbs.forEach((thumb, thumbIndex) => thumb.classList.toggle('active', thumbIndex === activeImage));
    }

    document.querySelector('.gallery-btn.prev').addEventListener('click', () => setImage(activeImage - 1));
    document.querySelector('.gallery-btn.next').addEventListener('click', () => setImage(activeImage + 1));
    thumbs.forEach(thumb => thumb.addEventListener('click', () => setImage(Number(thumb.dataset.index))));
</script>
@endsection
